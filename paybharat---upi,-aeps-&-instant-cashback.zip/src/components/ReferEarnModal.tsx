/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Users,
  Copy,
  Check,
  Share2,
  Gift,
  Sparkles,
  X,
  Coins,
  ArrowRight,
  ShieldCheck,
  MessageCircle,
  Send,
  Award,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Language, Transaction, UserProfile } from '../types';
import { formatINR } from '../utils/receiptGenerator';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  user: UserProfile;
  onRewardClaimed: (amount: number, friendName: string) => void;
}

export const ReferEarnModal: React.FC<Props> = ({
  isOpen,
  onClose,
  language,
  user,
  onRewardClaimed,
}) => {
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [invitedFriends, setInvitedFriends] = useState([
    { name: 'Vikas Kumar', phone: '+91 98391 •••••', status: 'CLAIMED', reward: 150, date: 'Yesterday' },
    { name: 'Pooja Tiwari', phone: '+91 94152 •••••', status: 'CLAIMED', reward: 150, date: '26 Oct' },
    { name: 'Amit Singh', phone: '+91 87654 •••••', status: 'PENDING', reward: 150, date: '28 Oct' },
    { name: 'Sunil Gupta', phone: '+91 99360 •••••', status: 'PENDING', reward: 150, date: 'Today' },
  ]);
  const [totalEarned, setTotalEarned] = useState(1350);
  const [simulatedClaiming, setSimulatedClaiming] = useState(false);

  if (!isOpen) return null;

  const referralCode = 'BHARAT9792';
  const referralLink = `https://paybharat.in/join?ref=${referralCode}`;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(referralCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleShareWhatsApp = () => {
    const text = encodeURIComponent(
      `⚡ PayBharat App डाउनलोड करें और पहले पेमेंट/रिचार्ज पर ₹50 + 5% गारंटीड कैशबैक पाएं!\n\nमेरा रेफरल कोड: *${referralCode}*\nडाउनलोड लिंक: ${referralLink}`
    );
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  const handleNativeShare = () => {
    if (navigator.share) {
      navigator
        .share({
          title: 'Join PayBharat - Instant 2% to 5% Cashback App',
          text: `Use my invite code ${referralCode} to get ₹50 free + up to 5% guaranteed instant cashback on every recharge & bill!`,
          url: referralLink,
        })
        .catch(() => {});
    } else {
      handleCopyLink();
    }
  };

  // Allow user to simulate a friend completing first recharge and claiming ₹150 instantly!
  const handleSimulateFriendJoin = () => {
    setSimulatedClaiming(true);
    setTimeout(() => {
      setSimulatedClaiming(false);
      const newFriendName = 'Rahul Verma';
      const rewardAmt = 150;
      setTotalEarned((prev) => prev + rewardAmt);
      setInvitedFriends((prev) => [
        {
          name: newFriendName,
          phone: '+91 91234 •••••',
          status: 'CLAIMED',
          reward: rewardAmt,
          date: 'Just now',
        },
        ...prev,
      ]);

      try {
        confetti({
          particleCount: 90,
          spread: 80,
          origin: { y: 0.6 },
        });
      } catch (err) {}

      onRewardClaimed(rewardAmt, newFriendName);
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 text-white shadow-2xl my-6">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/80 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 border-b border-slate-800 pb-4 mb-4">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 to-orange-500 text-slate-950 flex items-center justify-center shadow-lg shadow-amber-500/20">
            <Gift className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
              {language === 'hi' ? 'रेफर करें और ₹150 कमाएं' : 'Refer & Earn ₹150'}
              <span className="text-[10px] font-bold bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full border border-amber-500/30">
                Unlimited
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              {language === 'hi'
                ? 'दोस्त को आमंत्रित करें और उसके पहले भुगतान पर तुरंत ₹150 पाएं!'
                : 'Invite friends & earn ₹150 instant cash when they do their first payment!'}
            </p>
          </div>
        </div>

        {/* Hero Reward Stats Banner */}
        <div className="bg-gradient-to-br from-amber-500/20 via-orange-500/10 to-slate-950 rounded-2xl p-4 border border-amber-500/30 mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-amber-300 font-semibold uppercase tracking-wider">
              {language === 'hi' ? 'कुल रेफरल कमाई' : 'Total Referral Earnings'}
            </span>
            <span className="text-[11px] text-emerald-400 font-mono font-bold bg-emerald-500/10 px-2 py-0.5 rounded-md">
              Credited to Wallet
            </span>
          </div>

          <div className="flex items-end justify-between">
            <div className="text-3xl font-mono font-bold text-white">
              {formatINR(totalEarned)}
            </div>
            <div className="text-right text-xs text-slate-300">
              <span className="font-bold text-amber-400 font-mono">{invitedFriends.length}</span> Friends Invited
            </div>
          </div>
        </div>

        {/* Referral Code Box */}
        <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 mb-4 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium">
              {language === 'hi' ? 'आपका विशेष रेफरल कोड:' : 'Your Unique Referral Code:'}
            </span>
            <span className="text-[10px] text-emerald-400 font-semibold">Active · Lifetime</span>
          </div>

          <div className="flex items-center justify-between p-2.5 bg-slate-900 rounded-xl border border-dashed border-slate-700">
            <span className="font-mono font-bold text-lg text-amber-300 tracking-wider">
              {referralCode}
            </span>
            <button
              onClick={handleCopyCode}
              className="py-1 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-blue-400 text-xs font-semibold flex items-center gap-1 transition-colors"
            >
              {copiedCode ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" /> Copied!
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" /> Copy Code
                </>
              )}
            </button>
          </div>

          {/* Share Buttons Row */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              onClick={handleShareWhatsApp}
              className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all active:scale-95"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp Share</span>
            </button>

            <button
              onClick={handleNativeShare}
              className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-blue-600/20 transition-all active:scale-95"
            >
              <Share2 className="w-4 h-4" />
              <span>Share Invite Link</span>
            </button>
          </div>
        </div>

        {/* 3 Step How It Works */}
        <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 mb-4">
          <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-2">
            {language === 'hi' ? 'यह कैसे काम करता है:' : 'How Referral Works:'}
          </span>
          <div className="grid grid-cols-3 gap-2 text-center text-xs">
            <div className="p-2 bg-slate-900 rounded-xl border border-slate-800/80">
              <span className="w-5 h-5 rounded-full bg-blue-500/20 text-blue-400 font-bold mx-auto flex items-center justify-center text-[10px] mb-1">
                1
              </span>
              <span className="text-[11px] text-slate-300 block font-medium">
                {language === 'hi' ? 'लिंक शेयर करें' : 'Share Link'}
              </span>
              <span className="text-[10px] text-slate-500">To friends & family</span>
            </div>

            <div className="p-2 bg-slate-900 rounded-xl border border-slate-800/80">
              <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 font-bold mx-auto flex items-center justify-center text-[10px] mb-1">
                2
              </span>
              <span className="text-[11px] text-slate-300 block font-medium">
                {language === 'hi' ? 'पहला रिचार्ज' : 'First Payment'}
              </span>
              <span className="text-[10px] text-slate-500">Friend pays/recharges</span>
            </div>

            <div className="p-2 bg-slate-900 rounded-xl border border-slate-800/80">
              <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold mx-auto flex items-center justify-center text-[10px] mb-1">
                3
              </span>
              <span className="text-[11px] text-slate-300 block font-medium">
                {language === 'hi' ? 'दोनों को कैशबैक' : 'Both Win'}
              </span>
              <span className="text-[10px] text-emerald-400 font-bold">You get ₹150</span>
            </div>
          </div>
        </div>

        {/* Invited Friends List */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-slate-300">
              {language === 'hi' ? 'आमंत्रित मित्रों की सूची' : 'Invited Friends Activity'}
            </span>
            <span className="text-[11px] text-slate-500">{invitedFriends.length} total</span>
          </div>

          <div className="divide-y divide-slate-800 rounded-2xl bg-slate-950 border border-slate-800 max-h-36 overflow-y-auto pr-1">
            {invitedFriends.map((f, idx) => (
              <div key={idx} className="p-2.5 flex items-center justify-between text-xs">
                <div>
                  <div className="font-semibold text-white">{f.name}</div>
                  <div className="text-[10px] text-slate-500 font-mono">{f.phone} · {f.date}</div>
                </div>

                <div className="text-right">
                  {f.status === 'CLAIMED' ? (
                    <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full flex items-center gap-1">
                      <Sparkles className="w-2.5 h-2.5" /> +₹{f.reward} Earned
                    </span>
                  ) : (
                    <span className="text-[10px] font-medium text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full">
                      Pending Recharge
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Test / Simulate Friend Invite Bonus Button */}
        <div className="pt-2">
          <button
            onClick={handleSimulateFriendJoin}
            disabled={simulatedClaiming}
            className="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center justify-center gap-1.5 transition-all active:scale-95 disabled:opacity-50"
          >
            <Coins className="w-3.5 h-3.5 text-amber-400" />
            {simulatedClaiming
              ? language === 'hi'
                ? 'बोनस क्रेडिट हो रहा है...'
                : 'Crediting ₹150 Referral Reward...'
              : language === 'hi'
              ? 'सिमुलेशन: नए मित्र का ₹150 रेफरल बोनस अभी क्लेम करें'
              : 'Simulate: Friend Joins & Claim ₹150 Bonus Now'}
          </button>
        </div>
      </div>
    </div>
  );
};
