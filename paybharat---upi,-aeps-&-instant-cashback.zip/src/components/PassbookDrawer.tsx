/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  FileSpreadsheet,
  X,
  Search,
  ArrowUpRight,
  ArrowDownLeft,
  Smartphone,
  Zap,
  Fingerprint,
  Sparkles,
  Download,
  Filter,
  SlidersHorizontal,
  RotateCcw,
} from 'lucide-react';
import { Language, Transaction, UserProfile } from '../types';
import { formatINR, downloadStatementAsCSV } from '../utils/receiptGenerator';
import { TRANSLATIONS } from '../utils/translations';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  transactions: Transaction[];
  user: UserProfile;
  onSelectTxn: (txn: Transaction) => void;
  onOpenDownloadApp?: () => void;
}

export const PassbookDrawer: React.FC<Props> = ({
  isOpen,
  onClose,
  language,
  transactions,
  user,
  onSelectTxn,
  onOpenDownloadApp,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [amountRange, setAmountRange] = useState<string>('all');
  const [minAmount, setMinAmount] = useState<string>('');
  const [maxAmount, setMaxAmount] = useState<string>('');
  const [showAdvancedFilters, setShowAdvancedFilters] = useState<boolean>(false);

  if (!isOpen) return null;
  const t = TRANSLATIONS[language];

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setAmountRange('all');
    setMinAmount('');
    setMaxAmount('');
  };

  const hasActiveFilters =
    Boolean(searchQuery.trim()) ||
    selectedCategory !== 'all' ||
    amountRange !== 'all' ||
    Boolean(minAmount) ||
    Boolean(maxAmount);

  const filtered = transactions.filter((t) => {
    // 1. Category Filter
    if (selectedCategory !== 'all') {
      if (selectedCategory === 'recharge' && t.type !== 'recharge') return false;
      if (selectedCategory === 'bill' && t.type !== 'bill_pay') return false;
      if (selectedCategory === 'aeps' && !t.type.startsWith('aeps')) return false;
      if (selectedCategory === 'transfer' && t.type === 'send_money') {
        // match
      } else if (selectedCategory === 'transfer' && t.type !== 'send_money') {
        return false;
      }
      if (selectedCategory === 'cashback' && t.type !== 'cashback_credit') return false;
    }

    // 2. Search Query (Merchant Name, Title, UTR, Recipient Info, ID)
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchMerchant = t.recipientName.toLowerCase().includes(q);
      const matchTitle = t.title.toLowerCase().includes(q);
      const matchId = t.id.toLowerCase().includes(q);
      const matchUtr = t.utrNumber.toLowerCase().includes(q);
      const matchCategory = t.category.toLowerCase().includes(q);
      const matchInfo = t.recipientInfo.toLowerCase().includes(q);

      if (!matchMerchant && !matchTitle && !matchId && !matchUtr && !matchCategory && !matchInfo) {
        return false;
      }
    }

    // 3. Amount Range Filter
    const amt = t.amount;
    if (amountRange === 'under_500' && amt >= 500) return false;
    if (amountRange === '500_2000' && (amt < 500 || amt > 2000)) return false;
    if (amountRange === '2000_5000' && (amt < 2000 || amt > 5000)) return false;
    if (amountRange === 'above_5000' && amt <= 5000) return false;

    // Custom Min / Max input
    if (minAmount && amt < Number(minAmount)) return false;
    if (maxAmount && amt > Number(maxAmount)) return false;

    return true;
  });

  const getTxnIcon = (type: Transaction['type']) => {
    switch (type) {
      case 'recharge':
        return <Smartphone className="w-4 h-4 text-blue-400" />;
      case 'bill_pay':
        return <Zap className="w-4 h-4 text-amber-400" />;
      case 'aeps_withdrawal':
      case 'aeps_aadhaar_pay':
        return <Fingerprint className="w-4 h-4 text-orange-400" />;
      case 'receive_money':
      case 'cashback_credit':
        return <ArrowDownLeft className="w-4 h-4 text-emerald-400" />;
      default:
        return <ArrowUpRight className="w-4 h-4 text-slate-300" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg h-full bg-slate-900 border-l border-slate-800 p-5 sm:p-6 text-white shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                {language === 'hi' ? 'पासबुक एवं लेन-देन खोज' : 'Passbook & Transaction Search'}
              </h2>
              <p className="text-xs text-slate-400">
                {transactions.length} Total Records · {formatINR(user.totalCashbackLifetime)} Lifetime Cashback
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Download App Promo Strip */}
        {onOpenDownloadApp && (
          <div className="mb-3 p-2.5 rounded-2xl bg-gradient-to-r from-blue-900/40 via-indigo-900/30 to-slate-900 border border-blue-500/30 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-blue-400" />
              <div className="text-xs font-semibold text-slate-200">
                {language === 'hi' ? 'PayBharat ऐप डाउनलोड करें' : 'Download PayBharat App'}
              </div>
            </div>
            <button
              onClick={onOpenDownloadApp}
              className="py-1 px-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-[10px] flex items-center gap-1 shadow-sm transition-all whitespace-nowrap active:scale-95"
            >
              <Download className="w-3 h-3" />
              {language === 'hi' ? 'ऐप इंस्टॉल करें' : 'Install APK'}
            </button>
          </div>
        )}

        {/* Search Bar by Merchant Name, Category, or ID */}
        <div className="space-y-2 mb-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                language === 'hi'
                  ? 'मर्चेंट नाम, श्रेणी या UTR से खोजें...'
                  : 'Search merchant name, recipient, category, UTR...'
              }
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-9 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-white text-xs"
              >
                ✕
              </button>
            )}
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs scrollbar-none">
            {[
              { id: 'all', label: language === 'hi' ? 'सभी' : 'All' },
              { id: 'recharge', label: language === 'hi' ? 'रिचार्ज' : 'Recharges' },
              { id: 'bill', label: language === 'hi' ? 'बिल भुगतान' : 'Bills' },
              { id: 'aeps', label: language === 'hi' ? 'आधार एटीएम' : 'AePS' },
              { id: 'transfer', label: language === 'hi' ? 'मनी ट्रांसफर' : 'Transfers' },
              { id: 'cashback', label: language === 'hi' ? 'कैशबैक' : 'Cashback' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-2.5 py-1 rounded-lg whitespace-nowrap text-[11px] font-semibold transition-colors ${
                  selectedCategory === cat.id
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'bg-slate-800/80 text-slate-400 hover:text-white'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Amount Range Filter Bar Toggle */}
          <div className="flex items-center justify-between text-xs pt-1">
            <button
              onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
              className="text-slate-400 hover:text-white flex items-center gap-1 text-[11px]"
            >
              <SlidersHorizontal className="w-3 h-3 text-blue-400" />
              <span>
                {language === 'hi' ? 'राशि सीमा (Amount Range)' : 'Amount Range Filter'}
              </span>
            </button>

            {hasActiveFilters && (
              <button
                onClick={handleResetFilters}
                className="text-amber-400 hover:underline flex items-center gap-1 text-[11px]"
              >
                <RotateCcw className="w-3 h-3" />
                <span>{language === 'hi' ? 'फ़िल्टर हटाएं' : 'Reset'}</span>
              </button>
            )}
          </div>

          {/* Expandable Amount Range Controls */}
          {showAdvancedFilters && (
            <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-2 text-xs animate-in fade-in">
              <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                {language === 'hi' ? 'राशि के अनुसार फ़िल्टर करें:' : 'Filter By Transaction Amount:'}
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                {[
                  { id: 'all', label: 'Any' },
                  { id: 'under_500', label: '< ₹500' },
                  { id: '500_2000', label: '₹500 - ₹2K' },
                  { id: 'above_5000', label: '> ₹5K' },
                ].map((range) => (
                  <button
                    key={range.id}
                    onClick={() => {
                      setAmountRange(range.id);
                      setMinAmount('');
                      setMaxAmount('');
                    }}
                    className={`py-1 text-[11px] font-semibold rounded-lg border text-center transition-colors ${
                      amountRange === range.id
                        ? 'border-blue-500 bg-blue-600/20 text-blue-300'
                        : 'border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {range.label}
                  </button>
                ))}
              </div>

              {/* Custom Min / Max numeric inputs */}
              <div className="flex items-center gap-2 pt-1">
                <div className="relative flex-1">
                  <span className="absolute left-2.5 top-1.5 text-slate-500 text-[11px]">₹ Min:</span>
                  <input
                    type="number"
                    value={minAmount}
                    onChange={(e) => {
                      setMinAmount(e.target.value);
                      setAmountRange('custom');
                    }}
                    placeholder="0"
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-12 pr-2 py-1 text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div className="relative flex-1">
                  <span className="absolute left-2.5 top-1.5 text-slate-500 text-[11px]">₹ Max:</span>
                  <input
                    type="number"
                    value={maxAmount}
                    onChange={(e) => {
                      setMaxAmount(e.target.value);
                      setAmountRange('custom');
                    }}
                    placeholder="10000"
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-12 pr-2 py-1 text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Match counter */}
          <div className="text-[11px] text-slate-400 px-1 flex items-center justify-between">
            <span>
              {language === 'hi'
                ? `${filtered.length} लेन-देन मिले (${transactions.length} में से)`
                : `Showing ${filtered.length} of ${transactions.length} transactions`}
            </span>
            {hasActiveFilters && (
              <span className="text-emerald-400 font-semibold">Active Filter</span>
            )}
          </div>
        </div>

        {/* Transactions Feed */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-1 my-1">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-xs space-y-2">
              <p>{language === 'hi' ? 'कोई लेन-देन नहीं मिला।' : 'No transactions matched your filters.'}</p>
              <button
                onClick={handleResetFilters}
                className="text-blue-400 hover:underline text-xs"
              >
                {language === 'hi' ? 'फ़िल्टर साफ़ करें' : 'Clear search & filters'}
              </button>
            </div>
          ) : (
            filtered.map((txn) => (
              <div
                key={txn.id}
                onClick={() => onSelectTxn(txn)}
                className="p-3 bg-slate-950/70 hover:bg-slate-800/80 rounded-2xl border border-slate-800/90 cursor-pointer transition-all flex items-center justify-between gap-3 group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center shrink-0 group-hover:border-slate-700">
                    {getTxnIcon(txn.type)}
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-white truncate group-hover:text-blue-400 transition-colors">
                      {txn.title}
                    </div>
                    <div className="text-[11px] text-slate-300 truncate font-medium">
                      {txn.recipientName}
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono">
                      {txn.timestamp} · {txn.category}
                    </div>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <div className="text-xs font-mono font-bold text-white">
                    {formatINR(txn.amount)}
                  </div>
                  <div className="text-[10px] font-bold text-emerald-400 flex items-center justify-end gap-0.5 mt-0.5">
                    <Sparkles className="w-2.5 h-2.5" />
                    +{formatINR(txn.cashbackAmount)}
                  </div>
                  <span className="text-[10px] text-blue-400 group-hover:underline inline-block mt-0.5">
                    Slip →
                  </span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer actions: Download CSV & Download App */}
        <div className="pt-3 border-t border-slate-800 space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => downloadStatementAsCSV(filtered.length > 0 ? filtered : transactions)}
              className="py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-md transition-all active:scale-[0.98]"
            >
              <Download className="w-4 h-4" />
              {t.downloadStatement}
            </button>

            {onOpenDownloadApp && (
              <button
                onClick={onOpenDownloadApp}
                className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 font-semibold text-xs flex items-center justify-center gap-1.5 transition-all active:scale-[0.98]"
              >
                <Smartphone className="w-4 h-4 text-emerald-400" />
                {language === 'hi' ? 'ऐप डाउनलोड' : 'Download App'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
