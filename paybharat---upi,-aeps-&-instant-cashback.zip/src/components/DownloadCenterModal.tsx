/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Download,
  X,
  FileText,
  FileSpreadsheet,
  QrCode,
  Fingerprint,
  CheckCircle2,
  Calendar,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import { Language, Transaction, UserProfile } from '../types';
import { downloadReceiptAsImage, downloadStatementAsCSV, formatINR } from '../utils/receiptGenerator';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  transactions: Transaction[];
  user: UserProfile;
}

export const DownloadCenterModal: React.FC<Props> = ({
  isOpen,
  onClose,
  language,
  transactions,
  user,
}) => {
  const [downloadSuccessToast, setDownloadSuccessToast] = useState<string | null>(null);
  const [selectedTxnId, setSelectedTxnId] = useState<string>(transactions[0]?.id || '');
  const [statementRange, setStatementRange] = useState<'this_month' | 'last_3_months' | 'financial_year'>('this_month');

  if (!isOpen) return null;

  const triggerToast = (msg: string) => {
    setDownloadSuccessToast(msg);
    setTimeout(() => setDownloadSuccessToast(null), 3000);
  };

  const handleDownloadSingleReceipt = (txn: Transaction) => {
    downloadReceiptAsImage(txn);
    triggerToast(
      language === 'hi'
        ? `रसीद ${txn.id} सफलतापूर्वक डाउनलोड हो गई!`
        : `Receipt for ${txn.id} downloaded successfully!`
    );
  };

  const handleDownloadFullStatement = () => {
    downloadStatementAsCSV(transactions);
    triggerToast(
      language === 'hi'
        ? 'पूर्ण खाता स्टेटमेंट (CSV) डाउनलोड हो गया!'
        : 'Full account statement (CSV) downloaded successfully!'
    );
  };

  const handleDownloadMerchantQR = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 600;
    canvas.height = 780;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Card background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, 600, 780);

    // Header gradient
    const grad = ctx.createLinearGradient(0, 0, 600, 140);
    grad.addColorStop(0, '#0f172a');
    grad.addColorStop(1, '#1e293b');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 600, 140);

    // App title
    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 32px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('⚡ PayBharat UPI ⚡', 300, 60);

    ctx.fillStyle = '#94a3b8';
    ctx.font = '14px sans-serif';
    ctx.fillText('All UPI Apps Accepted Here · Zero Fee', 300, 95);

    // Merchant details
    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 24px sans-serif';
    ctx.fillText(user.name, 300, 190);

    ctx.fillStyle = '#64748b';
    ctx.font = '16px monospace';
    ctx.fillText(user.upiId, 300, 225);

    // QR container box
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.roundRect(140, 260, 320, 320, 20);
    ctx.stroke();

    // QR Graphics Simulation
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(170, 290, 80, 80);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(185, 305, 50, 50);
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(195, 315, 30, 30);

    ctx.fillRect(350, 290, 80, 80);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(365, 305, 50, 50);
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(375, 315, 30, 30);

    ctx.fillRect(170, 470, 80, 80);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(185, 485, 50, 50);
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(195, 495, 30, 30);

    // Middle badge
    ctx.fillStyle = '#3b82f6';
    ctx.beginPath();
    ctx.arc(300, 420, 36, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 28px sans-serif';
    ctx.fillText('₹', 300, 430);

    // Footer accepted logos
    ctx.fillStyle = '#10b981';
    ctx.font = 'bold 16px sans-serif';
    ctx.fillText('★ 2% to 5% Guaranteed Instant Cashback ★', 300, 630);

    ctx.fillStyle = '#94a3b8';
    ctx.font = '13px sans-serif';
    ctx.fillText('Google Pay · PhonePe · Paytm · BHIM · Amazon Pay', 300, 675);
    ctx.fillText('NPCI / UPI 2.0 Official Certified Standee', 300, 715);

    const a = document.createElement('a');
    a.download = `PayBharat_Merchant_Standee_${user.name.replace(/\s+/g, '_')}.png`;
    a.href = canvas.toDataURL('image/png');
    a.click();

    triggerToast(
      language === 'hi'
        ? 'व्यापारिक क्यूआर स्टैंडी (PNG) डाउनलोड हो गई!'
        : 'Official UPI QR Standee (PNG) downloaded!'
    );
  };

  const selectedTxn = transactions.find((t) => t.id === selectedTxnId) || transactions[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 text-white shadow-2xl my-6">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/80 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 border-b border-slate-800 pb-4 mb-5">
          <div className="w-10 h-10 rounded-2xl bg-blue-600/20 text-blue-400 flex items-center justify-center">
            <Download className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
              {language === 'hi' ? 'डाउनलोड केंद्र (Download Center)' : 'Download Center'}
              <span className="text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/30">
                Receipts & Reports
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              {language === 'hi'
                ? 'भुगतान रसीद, खाता स्टेटमेंट, आधार एटीएम स्लिप एवं क्यूआर स्टैंडी डाउनलोड करें'
                : 'Download receipts, account statements, AePS slips & merchant QR standees'}
            </p>
          </div>
        </div>

        {/* Success Toast banner */}
        {downloadSuccessToast && (
          <div className="mb-4 p-3 bg-emerald-950/80 border border-emerald-500/50 rounded-2xl text-xs text-emerald-300 font-bold flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{downloadSuccessToast}</span>
          </div>
        )}

        <div className="space-y-4">
          {/* Card 1: Download Single Transaction Receipt */}
          <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-blue-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  {language === 'hi' ? '1. लेन-देन रसीद डाउनलोड करें (PNG / PDF)' : '1. Download Payment Receipt (PNG)'}
                </span>
              </div>
              <span className="text-[10px] text-emerald-400 font-semibold">Official NPCI Slip</span>
            </div>

            <p className="text-xs text-slate-400 mb-3">
              {language === 'hi'
                ? 'किसी भी लेन-देन को चुनें और 1-क्लिक में हाई-रेज़ोल्यूशन रसीद डाउनलोड करें।'
                : 'Select any transaction to download official customer payment slip.'}
            </p>

            <div className="flex flex-col sm:flex-row gap-2 mb-3">
              <select
                value={selectedTxnId}
                onChange={(e) => setSelectedTxnId(e.target.value)}
                className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
              >
                {transactions.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.title} - {formatINR(t.amount)} ({t.timestamp})
                  </option>
                ))}
              </select>

              <button
                onClick={() => selectedTxn && handleDownloadSingleReceipt(selectedTxn)}
                className="py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md transition-all whitespace-nowrap active:scale-95"
              >
                <Download className="w-3.5 h-3.5" />
                {language === 'hi' ? 'रसीद डाउनलोड करें' : 'Download Receipt'}
              </button>
            </div>

            {selectedTxn && (
              <div className="p-2.5 bg-slate-900/60 rounded-xl border border-slate-800/80 text-[11px] text-slate-300 flex items-center justify-between">
                <span>UTR: <strong className="font-mono">{selectedTxn.utrNumber}</strong></span>
                <span className="text-emerald-400 font-bold">+{formatINR(selectedTxn.cashbackAmount)} Cashback</span>
              </div>
            )}
          </div>

          {/* Card 2: Download Full Statement (CSV / Excel) */}
          <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  {language === 'hi' ? '2. खाता पासबुक स्टेटमेंट (CSV / Excel)' : '2. Passbook Account Statement (CSV)'}
                </span>
              </div>
              <span className="text-[10px] text-slate-400">{transactions.length} Records</span>
            </div>

            <p className="text-xs text-slate-400 mb-3">
              {language === 'hi'
                ? 'सभी भुगतानों, रिचार्ज, आधार एटीएम निकासी एवं अर्जित कैशबैक का पूरा विवरण डाउनलोड करें।'
                : 'Download complete breakdown of all recharges, bills, AePS withdrawals, and cashback earned.'}
            </p>

            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-1 text-xs text-slate-300">
                <Calendar className="w-3.5 h-3.5 text-blue-400" />
                <span>Financial Year 2026-27 (Complete)</span>
              </div>

              <button
                onClick={handleDownloadFullStatement}
                className="py-2 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all whitespace-nowrap active:scale-95"
              >
                <Download className="w-3.5 h-3.5" />
                {language === 'hi' ? 'स्टेटमेंट डाउनलोड (CSV)' : 'Download Statement'}
              </button>
            </div>
          </div>

          {/* Card 3: Download Merchant / Receiving UPI Standee */}
          <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <QrCode className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  {language === 'hi' ? '3. दुकान / व्यक्तिगत क्यूआर स्टैंडी' : '3. Printable Merchant UPI QR Standee'}
                </span>
              </div>
              <span className="text-[10px] text-amber-300 font-semibold">Print-Ready (PNG)</span>
            </div>

            <p className="text-xs text-slate-400 mb-3">
              {language === 'hi'
                ? 'अपनी दुकान, काउंटर या पेमेंट स्वीकार करने हेतु प्रिंट करने योग्य आधिकारिक PayBharat QR स्टैंडी डाउनलोड करें।'
                : 'Generate and download your official printable QR standee for shop counter or personal payments.'}
            </p>

            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-slate-300 truncate max-w-[220px]">
                {user.upiId}
              </span>

              <button
                onClick={handleDownloadMerchantQR}
                className="py-2 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-all whitespace-nowrap active:scale-95"
              >
                <Download className="w-3.5 h-3.5" />
                {language === 'hi' ? 'स्टैंडी डाउनलोड करें' : 'Download Standee'}
              </button>
            </div>
          </div>
        </div>

        {/* Footer info */}
        <div className="mt-5 pt-3 border-t border-slate-800 text-center">
          <button
            onClick={onClose}
            className="text-xs text-slate-400 hover:text-white"
          >
            {language === 'hi' ? 'बंद करें (Close)' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
