/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState, useEffect } from 'react';
import { X, Sparkles, Check, Gift } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Language, Transaction } from '../types';
import { formatINR } from '../utils/receiptGenerator';

interface Props {
  txn: Transaction | null;
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const ScratchCardModal: React.FC<Props> = ({ txn, isOpen, onClose, language }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isScratched, setIsScratched] = useState(false);
  const [scratchProgress, setScratchProgress] = useState(0);

  useEffect(() => {
    if (isOpen && txn) {
      setIsScratched(false);
      setScratchProgress(0);
      setTimeout(initCanvas, 100);
    }
  }, [isOpen, txn]);

  const initCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Draw shimmering foil cover
    const grad = ctx.createLinearGradient(0, 0, width, height);
    grad.addColorStop(0, '#f59e0b');
    grad.addColorStop(0.3, '#fbbf24');
    grad.addColorStop(0.7, '#d97706');
    grad.addColorStop(1, '#b45309');

    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);

    // Decorative patterns
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 18px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('⚡ PayBharat ⚡', width / 2, 70);

    ctx.font = 'bold 22px sans-serif';
    ctx.fillText('SCRATCH HERE', width / 2, 130);

    ctx.font = '12px sans-serif';
    ctx.fillText('Guaranteed 2% to 5% Cashback', width / 2, 160);

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.lineWidth = 3;
    ctx.strokeRect(15, 15, width - 30, height - 30);
  };

  const handleScratch = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (isScratched) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    let clientX = 0;
    let clientY = 0;

    if ('touches' in e && e.touches[0]) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else if ('clientX' in e) {
      clientX = (e as React.MouseEvent).clientX;
      clientY = (e as React.MouseEvent).clientY;
    }

    const x = ((clientX - rect.left) / rect.width) * canvas.width;
    const y = ((clientY - rect.top) / rect.height) * canvas.height;

    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.arc(x, y, 28, 0, Math.PI * 2);
    ctx.fill();

    const newProgress = scratchProgress + 6;
    setScratchProgress(newProgress);

    if (newProgress >= 50 && !isScratched) {
      setIsScratched(true);
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch (err) {
        // ignore if not loaded
      }
    }
  };

  if (!isOpen || !txn) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white text-center shadow-2xl overflow-hidden">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-4">
          <span className="text-xs uppercase tracking-wider text-amber-400 font-bold flex items-center justify-center gap-1">
            <Sparkles className="w-4 h-4" />
            {language === 'hi' ? 'लकी कैशबैक स्क्रैच कार्ड' : 'Instant Cashback Card'}
          </span>
          <h3 className="text-lg font-bold text-white mt-1">
            {language === 'hi' ? 'स्क्रैच करें और कैशबैक पाएँ!' : 'Scratch & Win Guaranteed Cashback!'}
          </h3>
          <p className="text-xs text-slate-400">
            {language === 'hi'
              ? 'हर लेन-देन पर 2% से 5% सीधे वॉलेट में!'
              : '2% to 5% instant cashback credited to your wallet'}
          </p>
        </div>

        {/* Scratchable Card Box */}
        <div className="relative w-64 h-56 mx-auto rounded-2xl overflow-hidden shadow-2xl border-2 border-amber-400/40 select-none">
          {/* Card Underneath */}
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-600 via-teal-700 to-emerald-900 flex flex-col items-center justify-center p-4 text-white">
            <div className="w-12 h-12 rounded-full bg-emerald-400/20 flex items-center justify-center mb-1">
              <Gift className="w-7 h-7 text-emerald-300 animate-bounce" />
            </div>
            <span className="text-[11px] text-emerald-200 font-semibold uppercase tracking-wider">
              {language === 'hi' ? 'आपको मिला' : 'You Won'}
            </span>
            <div className="text-3xl font-mono font-bold text-white my-1">
              +{formatINR(txn.cashbackAmount)}
            </div>
            <span className="text-[11px] text-emerald-200 font-medium">
              ★ {(txn.cashbackRate * 100).toFixed(1)}% Instant Cashback
            </span>
            <span className="text-[10px] text-emerald-300/80 mt-1">
              Credited to PayBharat Wallet
            </span>
          </div>

          {/* Canvas Foil Overlay */}
          {!isScratched && (
            <canvas
              ref={canvasRef}
              width={256}
              height={224}
              onMouseMove={(e) => {
                if (e.buttons === 1) handleScratch(e);
              }}
              onTouchMove={handleScratch}
              className="absolute inset-0 w-full h-full cursor-pointer touch-none z-10"
            />
          )}
        </div>

        {/* Instructions */}
        <div className="mt-4">
          {!isScratched ? (
            <button
              onClick={() => {
                setIsScratched(true);
                try {
                  confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
                } catch (e) {}
              }}
              className="text-xs text-amber-400 hover:underline"
            >
              {language === 'hi' ? 'यहाँ क्लिक करके पूरा स्क्रैच करें' : 'Click here to instant-scratch'}
            </button>
          ) : (
            <button
              onClick={onClose}
              className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-xs uppercase tracking-wider shadow-lg shadow-emerald-500/20"
            >
              {language === 'hi' ? 'वॉलेट में जोड़ें एवं बंद करें' : 'Claim & Close'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
