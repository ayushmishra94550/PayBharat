/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  CheckCircle2,
  X,
  Download,
  Printer,
  Share2,
  Sparkles,
  ShieldCheck,
  ArrowRight,
  Copy,
} from 'lucide-react';
import { Language, Transaction } from '../types';
import { downloadReceiptAsImage, formatINR } from '../utils/receiptGenerator';
import { TRANSLATIONS } from '../utils/translations';

interface Props {
  txn: Transaction | null;
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onOpenScratchCard?: (txn: Transaction) => void;
}

export const ReceiptModal: React.FC<Props> = ({
  txn,
  isOpen,
  onClose,
  language,
  onOpenScratchCard,
}) => {
  if (!isOpen || !txn) return null;
  const t = TRANSLATIONS[language];

  const handleShare = () => {
    const text = `⚡ PayBharat Payment Receipt: ${formatINR(txn.amount)} paid to ${txn.recipientName}. UTR: ${txn.utrNumber}. Earned ${formatINR(txn.cashbackAmount)} instant cashback!`;
    if (navigator.share) {
      navigator.share({ title: 'PayBharat Payment Slip', text }).catch(() => {});
    } else {
      navigator.clipboard.writeText(text);
      alert('Receipt details copied to clipboard!');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 text-white shadow-2xl my-6">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/80 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Printable & Visible Receipt Section */}
        <div id="printable-receipt" className="space-y-4">
          {/* Top Brand Banner */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <span className="text-sm font-bold text-sky-400 tracking-tight">⚡ PayBharat</span>
              <span className="text-[10px] text-slate-400 block">NPCI / BBPS Official Slip</span>
            </div>
            <span className="text-[11px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
              ★ {(txn.cashbackRate * 100).toFixed(1)}% Cashback
            </span>
          </div>

          {/* Success Checkmark & Amount */}
          <div className="text-center pt-2">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center border border-emerald-500/30 mb-2">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <span className="text-xs uppercase tracking-wider text-emerald-400 font-bold">
              {t.paymentSuccess}
            </span>
            <div className="text-3xl sm:text-4xl font-mono font-bold text-white mt-1">
              {formatINR(txn.amount)}
            </div>
            <p className="text-xs text-slate-400 mt-1">
              {txn.title}
            </p>
          </div>

          {/* Instant Cashback Card */}
          <div className="p-3.5 bg-gradient-to-r from-emerald-950/60 to-teal-950/40 rounded-2xl border border-emerald-500/40 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-emerald-300">
                  {language === 'hi' ? 'तुरंत कैशबैक जमा हुआ!' : 'Instant Cashback Credited!'}
                </div>
                <div className="text-[10px] text-slate-400">
                  {(txn.cashbackRate * 100).toFixed(1)}% Cashback into Wallet
                </div>
              </div>
            </div>
            <span className="text-base font-mono font-bold text-emerald-400">
              +{formatINR(txn.cashbackAmount)}
            </span>
          </div>

          {/* Transaction Metadata Table */}
          <div className="bg-slate-950 rounded-2xl p-4 border border-slate-800 text-xs space-y-2.5">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">{t.transactionId}</span>
              <span className="font-mono text-slate-200">{txn.id}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">{t.paidTo}</span>
              <span className="text-slate-200 font-medium text-right max-w-[200px] truncate">{txn.recipientName}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Category / Detail</span>
              <span className="text-slate-300">{txn.category}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">{t.debitedFrom}</span>
              <span className="text-slate-300">{txn.paymentMethod}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">{t.refNo}</span>
              <span className="font-mono text-slate-200">{txn.utrNumber}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">{t.paymentDate}</span>
              <span className="text-slate-300">{txn.timestamp}</span>
            </div>
          </div>

          {/* NPCI Verified Security Stamp */}
          <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500 pt-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>NPCI Unified Payments Interface · 256-Bit SSL Encrypted</span>
          </div>
        </div>

        {/* Action Buttons: Download Receipt & Print */}
        <div className="grid grid-cols-2 gap-2 pt-4">
          <button
            onClick={() => downloadReceiptAsImage(txn)}
            className="py-3 px-3 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-blue-600/25 active:scale-[0.98] transition-all"
          >
            <Download className="w-4 h-4" />
            {language === 'hi' ? 'रसीद डाउनलोड (PNG)' : 'Download Receipt'}
          </button>
          <button
            onClick={() => window.print()}
            className="py-3 px-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 border border-slate-700 active:scale-[0.98] transition-all"
          >
            <Printer className="w-4 h-4" />
            {language === 'hi' ? 'प्रिंट रसीद' : 'Print / Save PDF'}
          </button>
        </div>

        {/* Secondary Actions */}
        <div className="flex items-center justify-between pt-3 text-xs">
          <button
            onClick={handleShare}
            className="text-slate-400 hover:text-white flex items-center gap-1 py-1"
          >
            <Share2 className="w-3.5 h-3.5" />
            {language === 'hi' ? 'रसीद शेयर करें' : 'Share Receipt'}
          </button>

          {onOpenScratchCard && (
            <button
              onClick={() => {
                onClose();
                onOpenScratchCard(txn);
              }}
              className="text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5" />
              {language === 'hi' ? 'स्क्रैच कार्ड खोलें' : 'Open Scratch Card'} →
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
