/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Users,
  Building,
  ArrowLeftRight,
  ShieldCheck,
  X,
  Sparkles,
  Check,
  ArrowRight,
  KeyRound,
  Eye,
  EyeOff,
} from 'lucide-react';
import { BankAccount, Language, Transaction, UserProfile } from '../types';
import { formatINR } from '../utils/receiptGenerator';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  user: UserProfile;
  banks: BankAccount[];
  initialMode?: 'mobile' | 'bank' | 'self' | 'check_balance';
  onSuccessPayment: (txn: Transaction) => void;
}

export const SendMoneyModal: React.FC<Props> = ({
  isOpen,
  onClose,
  language,
  user,
  banks,
  initialMode = 'mobile',
  onSuccessPayment,
}) => {
  const [mode, setMode] = useState<'mobile' | 'bank' | 'self' | 'check_balance'>(initialMode);

  // Transfer fields
  const [recipientContact, setRecipientContact] = useState('');
  const [recipientName, setRecipientName] = useState('Rahul Sharma');
  const [accountNumber, setAccountNumber] = useState('38910482910');
  const [ifscCode, setIfscCode] = useState('SBIN0001248');
  const [amount, setAmount] = useState<number>(500);
  const [selectedBankId, setSelectedBankId] = useState<string>(banks[0]?.id || '');
  const [note, setNote] = useState('Rent / Expense');

  // UPI PIN pad state
  const [showPinPad, setShowPinPad] = useState(false);
  const [upiPin, setUpiPin] = useState('');
  const [revealedBalance, setRevealedBalance] = useState<number | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const currentBank = banks.find((b) => b.id === selectedBankId) || banks[0];

  const handleStartPayment = () => {
    if (amount <= 0) return;
    setShowPinPad(true);
    setUpiPin('');
  };

  const handlePinDigit = (digit: string) => {
    if (upiPin.length < 4) {
      const nextPin = upiPin + digit;
      setUpiPin(nextPin);
      if (nextPin.length === 4) {
        // Auto submit PIN
        setIsProcessing(true);
        setTimeout(() => {
          setIsProcessing(false);
          setShowPinPad(false);

          if (mode === 'check_balance') {
            setRevealedBalance(currentBank.balance);
          } else {
            // Process transfer with 3.0% instant cashback
            const cashbackRate = 0.03;
            const cashbackAmount = Number((amount * cashbackRate).toFixed(2));
            const newTxn: Transaction = {
              id: `UPI-${Date.now().toString().slice(-8)}`,
              type: 'send_money',
              title:
                mode === 'mobile'
                  ? `Sent to ${recipientName}`
                  : mode === 'bank'
                  ? `Bank Transfer (${recipientName})`
                  : `Transfer to Self (${currentBank.bankName.split(' ')[0]})`,
              recipientName: recipientName,
              recipientInfo:
                mode === 'mobile'
                  ? recipientContact || '9876543210'
                  : `${accountNumber} (${ifscCode})`,
              amount,
              cashbackRate,
              cashbackAmount,
              status: 'SUCCESS',
              timestamp: 'Just now',
              utrNumber: `UTR${Math.floor(100000000000 + Math.random() * 900000000000)}`,
              paymentMethod: `UPI - ${currentBank.bankName}`,
              category: 'Money Transfer',
              notes: note,
              scratched: false,
            };

            onSuccessPayment(newTxn);
            onClose();
          }
        }, 900);
      }
    }
  };

  const handleDeletePin = () => {
    setUpiPin((prev) => prev.slice(0, -1));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 text-white shadow-2xl my-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-600/20 text-blue-400 flex items-center justify-center">
              {mode === 'mobile' ? (
                <Users className="w-5 h-5" />
              ) : mode === 'bank' ? (
                <Building className="w-5 h-5" />
              ) : (
                <ArrowLeftRight className="w-5 h-5" />
              )}
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                {mode === 'mobile'
                  ? language === 'hi'
                    ? 'मोबाइल नंबर पर भेजें'
                    : 'To Mobile / Contact'
                  : mode === 'bank'
                  ? language === 'hi'
                    ? 'बैंक खाता / IFSC'
                    : 'To Bank Account / IFSC'
                  : mode === 'self'
                  ? language === 'hi'
                    ? 'स्वयं के खाते में'
                    : 'To Self Account'
                  : language === 'hi'
                  ? 'बैंक बैलेंस चेक'
                  : 'Check Bank Balance'}
              </h2>
              <p className="text-xs text-slate-400">
                {language === 'hi'
                  ? '0% शुल्क एवं 2-5% तुरंत कैशबैक'
                  : 'Zero fee transfer with 2% - 5% instant cashback'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector */}
        <div className="grid grid-cols-4 gap-1 p-1 bg-slate-950 rounded-2xl border border-slate-800 mb-4 text-xs font-semibold">
          {[
            { id: 'mobile', label: language === 'hi' ? 'मोबाइल' : 'Mobile' },
            { id: 'bank', label: language === 'hi' ? 'बैंक खाता' : 'Bank A/C' },
            { id: 'self', label: language === 'hi' ? 'स्वयं' : 'Self' },
            { id: 'check_balance', label: language === 'hi' ? 'बैलेंस' : 'Balance' },
          ].map((m) => (
            <button
              key={m.id}
              onClick={() => {
                setMode(m.id as any);
                setShowPinPad(false);
                setRevealedBalance(null);
              }}
              className={`py-2 text-center rounded-xl transition-all ${
                mode === m.id
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>

        {/* Balance Display Screen */}
        {revealedBalance !== null ? (
          <div className="bg-slate-950 rounded-2xl p-6 border border-emerald-500/30 text-center space-y-4">
            <span className="text-xs uppercase text-slate-400 font-semibold tracking-wider">
              {currentBank.bankName}
            </span>
            <div className="text-3xl font-mono font-bold text-emerald-400">
              {formatINR(revealedBalance)}
            </div>
            <p className="text-xs text-slate-400">
              Account {currentBank.accountNumberMasked} · IFSC {currentBank.ifsc}
            </p>
            <button
              onClick={() => {
                setRevealedBalance(null);
                onClose();
              }}
              className="w-full py-2.5 rounded-xl bg-slate-800 text-white text-xs font-semibold hover:bg-slate-700"
            >
              Done
            </button>
          </div>
        ) : showPinPad ? (
          /* Secure UPI PIN Pad */
          <div className="bg-slate-950 rounded-2xl p-5 border border-slate-800 text-center space-y-4">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>{currentBank.bankName}</span>
              <span className="font-mono">{currentBank.accountNumberMasked}</span>
            </div>

            <div>
              <div className="text-xs uppercase tracking-wider text-slate-400 font-semibold">
                ENTER 4-DIGIT UPI PIN
              </div>
              {/* PIN Dots */}
              <div className="flex items-center justify-center gap-3 my-4">
                {[0, 1, 2, 3].map((i) => (
                  <div
                    key={i}
                    className={`w-3.5 h-3.5 rounded-full border-2 transition-all ${
                      i < upiPin.length
                        ? 'bg-emerald-400 border-emerald-400 scale-110'
                        : 'border-slate-600 bg-transparent'
                    }`}
                  />
                ))}
              </div>
              <p className="text-[11px] text-amber-400/90 flex items-center justify-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> NPCI Secure 256-Bit UPI Shield
              </p>
            </div>

            {/* Numeric Keypad */}
            <div className="grid grid-cols-3 gap-2 pt-2">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => handlePinDigit(String(num))}
                  className="h-12 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 active:scale-95 text-lg font-mono font-bold text-white transition-all"
                >
                  {num}
                </button>
              ))}
              <button
                type="button"
                onClick={() => setShowPinPad(false)}
                className="h-12 rounded-xl bg-slate-900 border border-slate-800 text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handlePinDigit('0')}
                className="h-12 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 active:scale-95 text-lg font-mono font-bold text-white"
              >
                0
              </button>
              <button
                type="button"
                onClick={handleDeletePin}
                className="h-12 rounded-xl bg-slate-900 border border-slate-800 text-xs font-semibold text-red-400 hover:bg-slate-800 active:scale-95"
              >
                ⌫
              </button>
            </div>
          </div>
        ) : (
          /* Form Inputs */
          <div className="space-y-4">
            {mode === 'mobile' && (
              <>
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    {language === 'hi' ? 'प्राप्तकर्ता का नाम' : 'Recipient Name'}
                  </label>
                  <input
                    type="text"
                    value={recipientName}
                    onChange={(e) => setRecipientName(e.target.value)}
                    placeholder="Enter name"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    {language === 'hi' ? 'मोबाइल नंबर / यूपीआई आईडी' : 'Mobile Number / UPI ID'}
                  </label>
                  <input
                    type="text"
                    value={recipientContact}
                    onChange={(e) => setRecipientContact(e.target.value)}
                    placeholder="e.g. 9876543210 or user@paytm"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs font-mono text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              </>
            )}

            {mode === 'bank' && (
              <>
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    {language === 'hi' ? 'बैंक खाता संख्या (A/C No)' : 'Bank Account Number'}
                  </label>
                  <input
                    type="text"
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                    placeholder="Enter Bank Account Number"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs font-mono text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">IFSC Code</label>
                    <input
                      type="text"
                      value={ifscCode}
                      onChange={(e) => setIfscCode(e.target.value.toUpperCase())}
                      placeholder="e.g. SBIN0001248"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs font-mono uppercase text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">
                      {language === 'hi' ? 'खाताधारक का नाम' : 'Beneficiary Name'}
                    </label>
                    <input
                      type="text"
                      value={recipientName}
                      onChange={(e) => setRecipientName(e.target.value)}
                      placeholder="Name as per passbook"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>
                </div>
              </>
            )}

            {mode !== 'check_balance' && (
              <>
                {/* Amount input */}
                <div>
                  <div className="flex items-center justify-between mb-1 text-xs">
                    <span className="text-slate-300 font-semibold">
                      {language === 'hi' ? 'राशि दर्ज करें (₹)' : 'Enter Amount (₹)'}
                    </span>
                    <span className="text-emerald-400 font-semibold flex items-center gap-1">
                      <Sparkles className="w-3 h-3" />
                      +₹{(amount * 0.03).toFixed(2)} Instant 3% Cashback
                    </span>
                  </div>
                  <div className="relative mb-2">
                    <span className="absolute left-3.5 top-2.5 font-bold font-mono text-slate-400">₹</span>
                    <input
                      type="number"
                      value={amount || ''}
                      onChange={(e) => setAmount(Number(e.target.value))}
                      min={1}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-4 py-2.5 text-base font-bold font-mono text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <div className="flex gap-2">
                    {[200, 500, 1000, 2000].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setAmount(amt)}
                        className={`flex-1 py-1 text-xs font-semibold rounded-lg border transition-colors ${
                          amount === amt
                            ? 'border-blue-500 bg-blue-500/20 text-blue-300'
                            : 'border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        ₹{amt}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Debiting Bank Account */}
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    {language === 'hi' ? 'भुगतान हेतु बैंक खाता' : 'Debit From Linked Bank'}
                  </label>
                  <select
                    value={selectedBankId}
                    onChange={(e) => setSelectedBankId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-blue-500"
                  >
                    {banks.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.bankName} - {b.accountNumberMasked} (Bal: ₹{b.balance.toLocaleString('en-IN')})
                      </option>
                    ))}
                  </select>
                </div>
              </>
            )}

            {mode === 'check_balance' && (
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  {language === 'hi' ? 'जिस बैंक का बैलेंस देखना है' : 'Select Bank to Check Balance'}
                </label>
                <select
                  value={selectedBankId}
                  onChange={(e) => setSelectedBankId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-blue-500"
                >
                  {banks.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.bankName} ({b.accountNumberMasked})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Action button */}
            <button
              onClick={handleStartPayment}
              disabled={isProcessing || (mode !== 'check_balance' && amount <= 0)}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 active:scale-[0.98] transition-all disabled:opacity-50"
            >
              <KeyRound className="w-4 h-4" />
              {mode === 'check_balance'
                ? language === 'hi'
                  ? 'यूपीआई पिन दर्ज करें'
                  : 'Enter UPI PIN for Balance'
                : language === 'hi'
                ? `₹${amount} सुरक्षित भेजें (यूपीआई पिन)`
                : `Proceed to Pay ${formatINR(amount)}`}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
