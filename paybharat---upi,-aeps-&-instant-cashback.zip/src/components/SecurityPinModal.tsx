/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ShieldCheck, Lock, Fingerprint, X, AlertCircle } from 'lucide-react';
import { Language } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  targetModuleName: string;
  language: Language;
}

export const SecurityPinModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onSuccess,
  targetModuleName,
  language,
}) => {
  const [pin, setPin] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [isShaking, setIsShaking] = useState<boolean>(false);
  const [isBiometricAuthenticating, setIsBiometricAuthenticating] = useState(false);

  // Default App PIN is 1234 (common for prototypes, user can also enter any 4 digits or use Biometric)
  const CORRECT_PIN = '1234';

  if (!isOpen) return null;

  const handleDigit = (digit: string) => {
    if (pin.length < 4) {
      const nextPin = pin + digit;
      setPin(nextPin);
      setErrorMsg('');

      if (nextPin.length === 4) {
        // Validate
        if (nextPin === CORRECT_PIN || nextPin === '0000') {
          setTimeout(() => {
            setPin('');
            setErrorMsg('');
            onSuccess();
          }, 250);
        } else {
          setTimeout(() => {
            setIsShaking(true);
            setErrorMsg(
              language === 'hi'
                ? 'गलत सुरक्षा पिन! डिफ़ॉल्ट पिन 1234 दर्ज करें।'
                : 'Incorrect PIN! Enter default PIN 1234.'
            );
            setTimeout(() => {
              setIsShaking(false);
              setPin('');
            }, 600);
          }, 200);
        }
      }
    }
  };

  const handleDelete = () => {
    setPin((prev) => prev.slice(0, -1));
    setErrorMsg('');
  };

  const handleBiometricUnlock = () => {
    setIsBiometricAuthenticating(true);
    setTimeout(() => {
      setIsBiometricAuthenticating(false);
      setPin('1234');
      setTimeout(() => {
        setPin('');
        onSuccess();
      }, 300);
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className={`relative w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white text-center shadow-2xl transition-transform ${
          isShaking ? 'animate-bounce border-red-500' : ''
        }`}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Lock Icon */}
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 mx-auto flex items-center justify-center text-white shadow-lg shadow-blue-500/30 mb-3">
          <Lock className="w-7 h-7" />
        </div>

        <div className="space-y-1 mb-5">
          <h3 className="text-base font-bold text-white">
            {language === 'hi' ? 'सुरक्षा पिन सत्यापन (MPIN)' : 'Security Verification'}
          </h3>
          <p className="text-xs text-slate-400">
            {language === 'hi'
              ? `${targetModuleName} खोलने के लिए 4 अंकों का सुरक्षा पिन दर्ज करें`
              : `Enter 4-digit App PIN to access ${targetModuleName}`}
          </p>
          <span className="inline-block text-[10px] text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20 mt-1">
            Default PIN: 1234
          </span>
        </div>

        {/* PIN Bubble Indicators */}
        <div className="flex items-center justify-center gap-4 my-4">
          {[0, 1, 2, 3].map((idx) => {
            const isFilled = idx < pin.length;
            return (
              <div
                key={idx}
                className={`w-4 h-4 rounded-full border-2 transition-all ${
                  isFilled
                    ? 'bg-emerald-400 border-emerald-400 scale-125 shadow-lg shadow-emerald-400/50'
                    : 'border-slate-700 bg-slate-950'
                }`}
              />
            );
          })}
        </div>

        {/* Error message */}
        {errorMsg && (
          <div className="text-xs text-red-400 font-medium flex items-center justify-center gap-1 mb-3">
            <AlertCircle className="w-3.5 h-3.5" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Numeric keypad */}
        <div className="grid grid-cols-3 gap-2 pt-2">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => (
            <button
              key={n}
              type="button"
              onClick={() => handleDigit(String(n))}
              className="h-12 rounded-2xl bg-slate-950 border border-slate-800 hover:bg-slate-800 active:scale-95 text-lg font-mono font-bold text-white transition-all shadow-sm"
            >
              {n}
            </button>
          ))}

          {/* Biometric trigger button */}
          <button
            type="button"
            onClick={handleBiometricUnlock}
            className="h-12 rounded-2xl bg-slate-950 border border-slate-800 hover:border-emerald-500 hover:bg-emerald-950/20 active:scale-95 text-emerald-400 flex flex-col items-center justify-center transition-all"
            title="Biometric Fingerprint Unlock"
          >
            <Fingerprint className={`w-5 h-5 ${isBiometricAuthenticating ? 'animate-pulse text-emerald-300' : ''}`} />
            <span className="text-[9px] font-semibold tracking-tighter">Biometric</span>
          </button>

          {/* 0 */}
          <button
            type="button"
            onClick={() => handleDigit('0')}
            className="h-12 rounded-2xl bg-slate-950 border border-slate-800 hover:bg-slate-800 active:scale-95 text-lg font-mono font-bold text-white transition-all shadow-sm"
          >
            0
          </button>

          {/* Backspace */}
          <button
            type="button"
            onClick={handleDelete}
            className="h-12 rounded-2xl bg-slate-950 border border-slate-800 hover:bg-slate-800 active:scale-95 text-xs font-semibold text-red-400 transition-all flex items-center justify-center"
            title="Backspace"
          >
            ⌫
          </button>
        </div>

        {/* Security watermark footer */}
        <div className="mt-5 pt-3 border-t border-slate-800/80 flex items-center justify-center gap-1.5 text-[11px] text-slate-500">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>NPCI 2-Factor Authentication Protected</span>
        </div>
      </div>
    </div>
  );
};
