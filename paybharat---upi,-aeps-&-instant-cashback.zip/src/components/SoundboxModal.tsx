/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Volume2, VolumeX, X, Radio, Check, Sparkles } from 'lucide-react';
import { Language, SoundboxConfig } from '../types';
import { playPaymentChime, speakSoundboxAlert } from '../utils/audioAlert';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  config: SoundboxConfig;
  onChangeConfig: (newConfig: SoundboxConfig) => void;
  currentLang: Language;
}

export const SoundboxModal: React.FC<Props> = ({
  isOpen,
  onClose,
  config,
  onChangeConfig,
}) => {
  const [testAmount, setTestAmount] = useState<number>(500);
  const [isPlaying, setIsPlaying] = useState(false);

  if (!isOpen) return null;

  const handleTestPlay = () => {
    setIsPlaying(true);
    playPaymentChime();
    speakSoundboxAlert(testAmount, config.language, (testAmount * 0.04));
    setTimeout(() => setIsPlaying(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white shadow-2xl overflow-hidden">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/80 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
            <Volume2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold">PayBharat Smart Soundbox</h3>
            <p className="text-xs text-slate-400">Instant Audio Payment & Cashback Alert</p>
          </div>
        </div>

        {/* Physical Soundbox Device Visual Representation */}
        <div className="bg-gradient-to-b from-blue-700 to-indigo-900 rounded-2xl p-5 mb-5 shadow-inner border border-blue-400/30">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs font-semibold tracking-wider uppercase text-blue-100">4G SIM Connected</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-blue-200 font-mono">
              <span>98% Battery</span>
              <Radio className="w-3.5 h-3.5 text-emerald-400" />
            </div>
          </div>

          {/* LCD Screen Display */}
          <div className="bg-slate-950/80 rounded-xl p-3 border border-blue-400/20 text-center mb-4">
            <span className="text-[11px] text-emerald-400 font-mono tracking-widest block uppercase">
              {isPlaying ? '••• BROADCASTING AUDIO •••' : 'READY FOR PAYMENTS'}
            </span>
            <div className="text-2xl font-bold font-mono text-white mt-1">
              ₹{testAmount}.00
            </div>
            <span className="text-[11px] text-amber-300 font-medium inline-flex items-center gap-1 mt-0.5">
              <Sparkles className="w-3 h-3" /> +₹{(testAmount * 0.04).toFixed(1)} Instant Cashback
            </span>
          </div>

          {/* Speaker Grill Holes simulation */}
          <div className="grid grid-cols-8 gap-1.5 justify-center opacity-40 px-6 py-2">
            {Array.from({ length: 24 }).map((_, i) => (
              <div key={i} className="w-2 h-2 rounded-full bg-blue-200" />
            ))}
          </div>
        </div>

        {/* Settings */}
        <div className="space-y-4">
          {/* Enable Voice toggle */}
          <div className="flex items-center justify-between p-3.5 bg-slate-800/60 rounded-xl border border-slate-700/60">
            <div>
              <div className="text-sm font-semibold">Soundbox Voice Alerts</div>
              <div className="text-xs text-slate-400">Announce payments out loud instantly</div>
            </div>
            <button
              onClick={() => onChangeConfig({ ...config, enabled: !config.enabled })}
              className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors ${
                config.enabled ? 'bg-emerald-500' : 'bg-slate-700'
              }`}
            >
              <div
                className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                  config.enabled ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Language selector */}
          <div className="p-3.5 bg-slate-800/60 rounded-xl border border-slate-700/60">
            <label className="text-xs font-semibold text-slate-300 block mb-2 uppercase tracking-wider">
              Audio Announcement Language
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => onChangeConfig({ ...config, language: 'hi' })}
                className={`py-2 px-3 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
                  config.language === 'hi'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {config.language === 'hi' && <Check className="w-3.5 h-3.5" />}
                Hindi (हिंदी)
              </button>
              <button
                type="button"
                onClick={() => onChangeConfig({ ...config, language: 'en' })}
                className={`py-2 px-3 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
                  config.language === 'en'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {config.language === 'en' && <Check className="w-3.5 h-3.5" />}
                English (Indian)
              </button>
            </div>
          </div>

          {/* Test amount slider / inputs */}
          <div className="p-3.5 bg-slate-800/60 rounded-xl border border-slate-700/60">
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="text-slate-300 font-medium">Test Payment Amount:</span>
              <span className="font-mono font-bold text-emerald-400">₹{testAmount}</span>
            </div>
            <div className="flex gap-2">
              {[100, 500, 1000, 2500].map((amt) => (
                <button
                  key={amt}
                  onClick={() => setTestAmount(amt)}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${
                    testAmount === amt
                      ? 'border-emerald-500 bg-emerald-500/20 text-emerald-300'
                      : 'border-slate-700 text-slate-400 hover:text-white'
                  }`}
                >
                  ₹{amt}
                </button>
              ))}
            </div>
          </div>

          {/* Test Speaker Button */}
          <button
            onClick={handleTestPlay}
            disabled={isPlaying}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-[0.98] transition-all disabled:opacity-50"
          >
            {isPlaying ? (
              <>
                <Volume2 className="w-4 h-4 animate-bounce" />
                Playing Soundbox Alert...
              </>
            ) : (
              <>
                <Volume2 className="w-4 h-4" />
                Play Test Voice Alert
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
