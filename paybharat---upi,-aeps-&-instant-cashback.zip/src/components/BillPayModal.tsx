/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Zap,
  Car,
  Tv,
  Flame,
  Droplet,
  Wifi,
  CreditCard,
  X,
  Search,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Building2,
} from 'lucide-react';
import { BillCategory, Language, Transaction } from '../types';
import { BILLERS } from '../data/mockData';
import { formatINR } from '../utils/receiptGenerator';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  initialCategory?: BillCategory;
  onSuccessPayment: (txn: Transaction) => void;
}

export const BillPayModal: React.FC<Props> = ({
  isOpen,
  onClose,
  language,
  initialCategory = 'electricity',
  onSuccessPayment,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<BillCategory>(initialCategory);
  const [searchBiller, setSearchBiller] = useState('');
  const [selectedBillerId, setSelectedBillerId] = useState<string>(
    BILLERS.find((b) => b.category === initialCategory)?.id || BILLERS[0].id
  );
  const [identifierInput, setIdentifierInput] = useState('104829183921');
  const [billFetched, setBillFetched] = useState<boolean>(true);
  const [billAmount, setBillAmount] = useState<number>(1840);
  const [dueDate, setDueDate] = useState<string>('05 Nov 2026');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const categories: Array<{ id: BillCategory; name: string; hiName: string; icon: React.ElementType }> = [
    { id: 'electricity', name: 'Electricity', hiName: 'बिजली बिल', icon: Zap },
    { id: 'fastag', name: 'FASTag', hiName: 'फास्टैग', icon: Car },
    { id: 'dth', name: 'DTH TV', hiName: 'डीटीएच टीवी', icon: Tv },
    { id: 'cylinder', name: 'Gas Cylinder', hiName: 'गैस सिलेंडर', icon: Flame },
    { id: 'water', name: 'Water', hiName: 'पानी बिल', icon: Droplet },
    { id: 'broadband', name: 'Broadband', hiName: 'ब्रॉडबैंड', icon: Wifi },
    { id: 'credit_card', name: 'Credit Card', hiName: 'क्रेडिट कार्ड', icon: CreditCard },
  ];

  const filteredBillers = BILLERS.filter(
    (b) =>
      b.category === selectedCategory &&
      (b.name.toLowerCase().includes(searchBiller.toLowerCase()) ||
        (b.state && b.state.toLowerCase().includes(searchBiller.toLowerCase())))
  );

  const currentBiller = BILLERS.find((b) => b.id === selectedBillerId) || filteredBillers[0] || BILLERS[0];

  const handleSelectBiller = (id: string) => {
    setSelectedBillerId(id);
    const b = BILLERS.find((x) => x.id === id);
    if (b) {
      setBillAmount(b.sampleAmount);
      setBillFetched(true);
    }
  };

  const handlePayBill = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      const cashbackRate = 0.04; // 4% instant cashback
      const cashbackAmount = Number((billAmount * cashbackRate).toFixed(2));

      const newTxn: Transaction = {
        id: `BBPS-${Date.now().toString().slice(-8)}`,
        type: 'bill_pay',
        title: `${currentBiller.name} Bill`,
        recipientName: currentBiller.name,
        recipientInfo: `${currentBiller.identifierLabel}: ${identifierInput}`,
        amount: billAmount,
        cashbackRate,
        cashbackAmount,
        status: 'SUCCESS',
        timestamp: 'Just now',
        utrNumber: `UTR${Math.floor(100000000000 + Math.random() * 900000000000)}`,
        paymentMethod: 'PayBharat UPI Linked Account',
        category: `${selectedCategory.toUpperCase()} Bill`,
        scratched: false,
      };

      onSuccessPayment(newTxn);
      onClose();
    }, 1300);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 text-white shadow-2xl my-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                {language === 'hi' ? 'भारत बिलपे (BBPS)' : 'Bharat BillPay (BBPS)'}
                <span className="text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  Govt / BBPS Assured
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                {language === 'hi'
                  ? 'बिजली, पानी, गैस, फास्टैग बिल पर 2% से 5% तुरंत कैशबैक'
                  : 'Pay utility bills & get guaranteed 2% to 5% instant cashback'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category Icons Row */}
        <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-4 text-xs scrollbar-none">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isCatSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => {
                  setSelectedCategory(cat.id);
                  const firstOfCat = BILLERS.find((b) => b.category === cat.id);
                  if (firstOfCat) {
                    setSelectedBillerId(firstOfCat.id);
                    setBillAmount(firstOfCat.sampleAmount);
                  }
                }}
                className={`flex flex-col items-center gap-1.5 p-2.5 min-w-[76px] rounded-2xl border transition-all ${
                  isCatSelected
                    ? 'border-blue-500 bg-blue-600/20 text-white shadow-md'
                    : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-white'
                }`}
              >
                <Icon className={`w-5 h-5 ${isCatSelected ? 'text-blue-400' : 'text-slate-400'}`} />
                <span className="text-[11px] font-semibold text-center leading-tight">
                  {language === 'hi' ? cat.hiName : cat.name}
                </span>
              </button>
            );
          })}
        </div>

        {/* Biller Search & Select */}
        <div className="space-y-4 mb-4">
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1.5 flex items-center justify-between">
              <span>{language === 'hi' ? 'बिलर / बोर्ड चुनें' : 'Select Biller / Service Provider'}</span>
              <span className="text-slate-500 text-[11px]">{filteredBillers.length} Providers Available</span>
            </label>
            <div className="relative mb-2">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchBiller}
                onChange={(e) => setSearchBiller(e.target.value)}
                placeholder="Search provider by name or state..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-blue-500"
              />
            </div>
            <select
              value={currentBiller?.id}
              onChange={(e) => handleSelectBiller(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-blue-500"
            >
              {filteredBillers.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name} {b.state ? `(${b.state})` : ''}
                </option>
              ))}
            </select>
          </div>

          {/* Account Identifier Input */}
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1.5">
              {currentBiller?.identifierLabel || 'Consumer ID'}
            </label>
            <input
              type="text"
              value={identifierInput}
              onChange={(e) => setIdentifierInput(e.target.value)}
              placeholder={currentBiller?.identifierPlaceholder}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {/* Fetched Bill Card */}
        {billFetched && (
          <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 mb-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-semibold text-slate-300">
                  {language === 'hi' ? 'बिल विवरण (सत्यापित)' : 'Bill Details Fetched'}
                </span>
              </div>
              <span className="text-[11px] text-amber-400 font-medium">Due Date: {dueDate}</span>
            </div>

            <div className="flex items-end justify-between">
              <div>
                <span className="text-xs text-slate-400">Total Bill Amount:</span>
                <div className="text-2xl font-bold font-mono text-white">
                  {formatINR(billAmount)}
                </div>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-400">Instant Cashback:</span>
                <div className="text-sm font-bold font-mono text-emerald-400 flex items-center gap-1 justify-end">
                  <Sparkles className="w-3.5 h-3.5" />
                  +₹{(billAmount * 0.04).toFixed(2)} (4.0%)
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Submit Button */}
        <button
          onClick={handlePayBill}
          disabled={isProcessing || !identifierInput}
          className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-600 to-emerald-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 active:scale-[0.98] transition-all disabled:opacity-50"
        >
          {isProcessing ? (
            'Processing BBPS Payment...'
          ) : (
            <>
              <ShieldCheck className="w-4 h-4" />
              {language === 'hi'
                ? `₹${billAmount} का सुरक्षित बिल भुगतान करें`
                : `Pay ${formatINR(billAmount)} with Instant Cashback`}
              <ArrowRight className="w-4 h-4 ml-1" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};
