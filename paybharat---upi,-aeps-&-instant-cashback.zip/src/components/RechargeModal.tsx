/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Smartphone,
  X,
  Search,
  Sparkles,
  Zap,
  Check,
  ShieldCheck,
  ArrowRight,
} from 'lucide-react';
import { Language, RechargePlan, Transaction } from '../types';
import { RECHARGE_PLANS } from '../data/mockData';
import { formatINR } from '../utils/receiptGenerator';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onSuccessPayment: (txn: Transaction) => void;
}

export const RechargeModal: React.FC<Props> = ({
  isOpen,
  onClose,
  language,
  onSuccessPayment,
}) => {
  const [mobileNumber, setMobileNumber] = useState('9792621480');
  const [operator, setOperator] = useState<'Jio' | 'Airtel' | 'Vi' | 'BSNL'>('Jio');
  const [selectedPlan, setSelectedPlan] = useState<RechargePlan>(RECHARGE_PLANS[0]);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const operators = [
    { name: 'Jio', color: 'from-blue-600 to-blue-800' },
    { name: 'Airtel', color: 'from-red-600 to-red-800' },
    { name: 'Vi', color: 'from-yellow-600 to-red-600' },
    { name: 'BSNL', color: 'from-sky-600 to-blue-700' },
  ] as const;

  const filteredPlans = RECHARGE_PLANS.filter((p) => {
    if (p.operator !== operator) return false;
    if (activeCategory === 'All') return true;
    return p.category === activeCategory;
  });

  const handlePayRecharge = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      const cashbackRate = selectedPlan.cashbackPercent / 100;
      const cashbackAmount = Number((selectedPlan.price * cashbackRate).toFixed(2));

      const newTxn: Transaction = {
        id: `REC-${Date.now().toString().slice(-8)}`,
        type: 'recharge',
        title: `${operator} Prepaid Recharge (₹${selectedPlan.price})`,
        recipientName: `${operator} Mobile - ${mobileNumber}`,
        recipientInfo: mobileNumber,
        amount: selectedPlan.price,
        cashbackRate,
        cashbackAmount,
        status: 'SUCCESS',
        timestamp: 'Just now',
        utrNumber: `UTR${Math.floor(100000000000 + Math.random() * 900000000000)}`,
        paymentMethod: 'PayBharat UPI Balance',
        category: 'Mobile Recharge',
        scratched: false,
      };

      onSuccessPayment(newTxn);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 text-white shadow-2xl my-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-600/20 text-blue-400 flex items-center justify-center">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                {language === 'hi' ? 'मोबाइल रिचार्ज' : 'Mobile Prepaid Recharge'}
                <span className="text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/30 flex items-center gap-1">
                  <Sparkles className="w-2.5 h-2.5" /> 2% - 5% Cashback
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                {language === 'hi'
                  ? 'तुरंत रिचार्ज एवं सीधे वॉलेट में 2-5% कैशबैक'
                  : 'Instant recharge & guaranteed 2-5% cashback credited directly'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mobile Number & Auto Circle Detection */}
        <div className="space-y-4 mb-5">
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1.5">
              {language === 'hi' ? 'मोबाइल नंबर दर्ज करें' : 'Enter 10-Digit Mobile Number'}
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-2.5 text-xs font-mono font-bold text-slate-400">+91</span>
              <input
                type="tel"
                value={mobileNumber}
                onChange={(e) => setMobileNumber(e.target.value.replace(/\D/g, '').slice(0, 10))}
                placeholder="98765 43210"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-12 pr-4 py-2.5 text-sm font-mono font-semibold text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          {/* Operator Selector */}
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1.5">
              {language === 'hi' ? 'ऑपरेटर चुनें' : 'Select Telecom Operator'}
            </label>
            <div className="grid grid-cols-4 gap-2">
              {operators.map((op) => (
                <button
                  key={op.name}
                  onClick={() => {
                    setOperator(op.name);
                    const firstPlan = RECHARGE_PLANS.find((p) => p.operator === op.name);
                    if (firstPlan) setSelectedPlan(firstPlan);
                  }}
                  className={`py-2 px-3 rounded-xl text-xs font-bold transition-all border ${
                    operator === op.name
                      ? 'border-blue-500 bg-blue-600/20 text-white shadow-md'
                      : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-white'
                  }`}
                >
                  {op.name}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Plan Filter Categories */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-3 text-xs">
          {['All', 'Daily Data', 'Unlimited', 'Long Term', 'Entertainment OTT', 'Data Booster'].map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-medium transition-colors ${
                activeCategory === cat
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-800/80 text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Plans List */}
        <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1 mb-5">
          {filteredPlans.map((plan) => {
            const isSelected = selectedPlan.id === plan.id;
            const cashbackVal = (plan.price * (plan.cashbackPercent / 100)).toFixed(1);

            return (
              <div
                key={plan.id}
                onClick={() => setSelectedPlan(plan)}
                className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'border-blue-500 bg-blue-950/30 shadow-md ring-1 ring-blue-500'
                    : 'border-slate-800 bg-slate-950 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-bold font-mono text-white">
                        ₹{plan.price}
                      </span>
                      <span className="text-xs text-slate-400 font-medium">
                        · {plan.validity}
                      </span>
                      <span className="text-xs text-blue-400 font-semibold">
                        · {plan.data}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 mt-1">{plan.benefits}</p>
                  </div>

                  {/* Cashback Callout */}
                  <div className="text-right shrink-0">
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                      <Sparkles className="w-3 h-3" />
                      +{formatINR(Number(cashbackVal))} Cashback ({plan.cashbackPercent}%)
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Plan Summary & Checkout Bar */}
        <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 mb-4 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">Total Recharge Amount:</div>
            <div className="text-xl font-bold font-mono text-white">
              ₹{selectedPlan.price}.00
            </div>
          </div>
          <div className="text-right">
            <div className="text-xs text-slate-400">Instant Cashback to Wallet:</div>
            <div className="text-sm font-bold font-mono text-emerald-400 flex items-center justify-end gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              +₹{((selectedPlan.price * selectedPlan.cashbackPercent) / 100).toFixed(2)}
            </div>
          </div>
        </div>

        {/* Pay Button */}
        <button
          onClick={handlePayRecharge}
          disabled={isProcessing || mobileNumber.length < 10}
          className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-600 to-emerald-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 active:scale-[0.98] transition-all disabled:opacity-50"
        >
          {isProcessing ? (
            'Processing Recharge...'
          ) : (
            <>
              <ShieldCheck className="w-4 h-4" />
              {language === 'hi'
                ? `₹${selectedPlan.price} का सुरक्षित रिचार्ज करें`
                : `Pay ₹${selectedPlan.price} & Get Instant Cashback`}
              <ArrowRight className="w-4 h-4 ml-1" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};
