/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Sparkles,
  X,
  Award,
  TrendingUp,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Gift,
  Coins,
  Building,
} from 'lucide-react';
import { BankAccount, Language, UserProfile } from '../types';
import { formatINR } from '../utils/receiptGenerator';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  user: UserProfile;
  primaryBank: BankAccount;
  onTransferCashback: (amt: number) => void;
}

export const CashbackRewardsHub: React.FC<Props> = ({
  isOpen,
  onClose,
  language,
  user,
  primaryBank,
  onTransferCashback,
}) => {
  const [transferred, setTransferred] = useState(false);

  if (!isOpen) return null;

  const handleWithdrawCashback = () => {
    if (user.cashbackBalance <= 0) return;
    onTransferCashback(user.cashbackBalance);
    setTransferred(true);
    setTimeout(() => {
      setTransferred(false);
      onClose();
    }, 2200);
  };

  const cashbackRates = [
    { category: 'Mobile Prepaid Recharge', rate: 'Up to 5.0% Instant' },
    { category: 'Electricity & Gas Bills (BBPS)', rate: 'Up to 5.0% Instant' },
    { category: 'Merchant QR Scanner Payments', rate: '3.0% to 5.0% Instant' },
    { category: 'FASTag & DTH Recharges', rate: '3.5% to 4.5% Instant' },
    { category: 'AePS Aadhaar Cash Withdrawal', rate: '2.0% to 3.5% Commission' },
    { category: 'Water & Broadband Bill', rate: '3.0% to 4.0% Instant' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 text-white shadow-2xl my-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <Sparkles className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                {language === 'hi' ? 'कैशबैक एवं रिवॉर्ड्स हब' : 'Cashback & Rewards Hub'}
                <span className="text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  2% - 5% Active
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                {language === 'hi'
                  ? 'हर ट्रांजेक्शन पर 2 से 5 प्रतिशत तुरंत कैशबैक की गारंटी'
                  : 'Guaranteed 2% to 5% instant cashback credited on every txn'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Hero Cashback Card */}
        <div className="bg-gradient-to-br from-emerald-900/60 via-teal-900/40 to-slate-950 rounded-2xl p-5 border border-emerald-500/40 mb-5 relative overflow-hidden">
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-emerald-300 uppercase tracking-wider">
                {language === 'hi' ? 'कुल संचित कैशबैक' : 'Available Cashback Balance'}
              </span>
              <span className="text-xs font-bold text-amber-300 bg-amber-500/20 px-2.5 py-0.5 rounded-full border border-amber-500/30">
                {user.tier}
              </span>
            </div>

            <div className="text-3xl sm:text-4xl font-mono font-bold text-white my-1">
              {formatINR(user.cashbackBalance)}
            </div>

            <div className="flex items-center gap-4 text-xs text-emerald-200 mt-2">
              <div>
                <span className="text-slate-400 block text-[10px]">Lifetime Total Saved</span>
                <span className="font-mono font-bold text-white">{formatINR(user.totalCashbackLifetime)}</span>
              </div>
              <div className="h-6 w-px bg-emerald-500/30" />
              <div>
                <span className="text-slate-400 block text-[10px]">Instant Credit Rate</span>
                <span className="font-bold text-emerald-300">2.0% - 5.0%</span>
              </div>
            </div>
          </div>
        </div>

        {/* Transfer Cashback to Bank Action */}
        <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 mb-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Building className="w-4 h-4 text-blue-400" />
              <div className="text-xs font-semibold text-white">
                {language === 'hi' ? 'कैशबैक को मुख्य बैंक में भेजें' : 'Transfer Cashback to Bank A/C'}
              </div>
            </div>
            <span className="text-[11px] text-slate-400 font-mono">0% Transfer Fee</span>
          </div>

          <div className="text-xs text-slate-400 mb-3">
            Directly move your earned cashback to <strong className="text-slate-200">{primaryBank.bankName} ({primaryBank.accountNumberMasked})</strong> with instant settlement.
          </div>

          {transferred ? (
            <div className="p-3 bg-emerald-950/60 text-emerald-300 rounded-xl border border-emerald-500/40 text-xs font-bold flex items-center justify-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              Cashback successfully transferred to your bank!
            </div>
          ) : (
            <button
              onClick={handleWithdrawCashback}
              disabled={user.cashbackBalance <= 0}
              className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all disabled:opacity-50"
            >
              <Coins className="w-4 h-4" />
              {language === 'hi'
                ? `पूरा कैशबैक (${formatINR(user.cashbackBalance)}) बैंक में ट्रांसफर करें`
                : `Transfer ${formatINR(user.cashbackBalance)} to Bank Account`}
            </button>
          )}
        </div>

        {/* Guaranteed Rates Table */}
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
            {language === 'hi' ? '2% से 5% कैशबैक नियम एवं दरें' : 'Guaranteed Cashback Rates by Category'}
          </h3>
          <div className="divide-y divide-slate-800/80 rounded-2xl bg-slate-950 border border-slate-800 p-1 text-xs">
            {cashbackRates.map((item, idx) => (
              <div key={idx} className="p-2.5 flex items-center justify-between">
                <span className="text-slate-300">{item.category}</span>
                <span className="font-mono font-bold text-emerald-400 text-[11px] bg-emerald-500/10 px-2 py-0.5 rounded-md">
                  {item.rate}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
