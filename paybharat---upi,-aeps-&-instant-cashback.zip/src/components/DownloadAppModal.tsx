/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Smartphone,
  Download,
  X,
  ShieldCheck,
  CheckCircle2,
  Star,
  QrCode,
  Share2,
  Sparkles,
  Zap,
} from 'lucide-react';
import { Language } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const DownloadAppModal: React.FC<Props> = ({ isOpen, onClose, language }) => {
  const [downloadStarted, setDownloadStarted] = useState(false);

  if (!isOpen) return null;

  const handleDownloadAPK = () => {
    setDownloadStarted(true);
    // Create and trigger download of mock PayBharat APK installer package
    const apkData = `PAYBHARAT_PACKAGE_METADATA
Package: com.paybharat.upi.aeps
Version: 2.4.0-release
Name: PayBharat - UPI, AePS & Instant Cashback
Target: Android 8.0+ / Web PWA
Integrations: NPCI UPI, Bharat BillPay BBPS, UIDAI RD AePS
Status: Verified & Signed
Guaranteed Cashback: 2% to 5% Instant
Timestamp: ${new Date().toISOString()}
`;
    const blob = new Blob([apkData], { type: 'application/vnd.android.package-archive' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'PayBharat_v2.4_Official.apk';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setTimeout(() => {
      setDownloadStarted(false);
    }, 3500);
  };

  const handlePwaInstall = () => {
    // Check if deferredPrompt exists or provide instructions
    const isPWA = window.matchMedia('(display-mode: standalone)').matches;
    if (isPWA) {
      alert('PayBharat is already installed as a progressive web app!');
    } else {
      alert(
        language === 'hi'
          ? 'ऐप इंस्टॉल करने के लिए अपने ब्राउज़र मेन्यू में "Add to Home Screen" या "Install PayBharat" चुनें।'
          : 'To install the app, tap the browser menu (⋮ or Share) and select "Add to Home Screen" or "Install App".'
      );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 text-white shadow-2xl my-6 text-center">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/80 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* App Icon Banner */}
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-teal-500 mx-auto flex items-center justify-center text-white text-2xl font-bold shadow-xl shadow-blue-500/25 mb-3 border border-blue-400/30">
          <span>₹</span>
        </div>

        <h3 className="text-lg font-bold text-white flex items-center justify-center gap-1.5">
          <span>PayBharat App</span>
          <span className="text-[10px] font-bold bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/30">
            v2.4
          </span>
        </h3>
        <p className="text-xs text-slate-400 mt-1">
          {language === 'hi'
            ? 'भारत का सबसे तेज़ 2-5% कैशबैक एवं आधार एटीएम ऐप'
            : "India's fastest UPI, AePS ATM & 2% - 5% instant cashback app"}
        </p>

        {/* Rating and Reviews */}
        <div className="flex items-center justify-center gap-4 my-3 text-xs text-slate-300">
          <div className="flex items-center gap-1">
            <span className="font-bold text-amber-400 font-mono">4.8</span>
            <div className="flex text-amber-400">
              <Star className="w-3.5 h-3.5 fill-current" />
              <Star className="w-3.5 h-3.5 fill-current" />
              <Star className="w-3.5 h-3.5 fill-current" />
              <Star className="w-3.5 h-3.5 fill-current" />
              <Star className="w-3.5 h-3.5 fill-current" />
            </div>
          </div>
          <span>·</span>
          <span>1.2M+ Reviews</span>
          <span>·</span>
          <span className="text-emerald-400 font-medium">50M+ Downloads</span>
        </div>

        {/* Features highlights */}
        <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 text-left text-xs space-y-2 mb-4">
          <div className="flex items-center gap-2 text-emerald-300 font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>2% to 5% Instant Guaranteed Cashback on every recharge</span>
          </div>
          <div className="flex items-center gap-2 text-slate-300">
            <Zap className="w-3.5 h-3.5 text-blue-400 shrink-0" />
            <span>AePS Aadhaar ATM with Biometric Fingerprint Auth</span>
          </div>
          <div className="flex items-center gap-2 text-slate-300">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>NPCI UPI Verified & BBPS Certified Utility Hub</span>
          </div>
        </div>

        {/* Download Buttons */}
        <div className="space-y-2.5">
          <button
            onClick={handleDownloadAPK}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-[0.98] transition-all"
          >
            <Download className="w-4 h-4" />
            {downloadStarted
              ? language === 'hi'
                ? 'APK डाउनलोड हो रहा है...'
                : 'Downloading APK Package...'
              : language === 'hi'
              ? 'एंड्रॉयड ऐप डाउनलोड करें (APK - 18 MB)'
              : 'Download Android App (Direct APK - 18 MB)'}
          </button>

          <button
            onClick={handlePwaInstall}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-2 border border-slate-700 active:scale-[0.98] transition-all"
          >
            <Smartphone className="w-4 h-4 text-blue-400" />
            {language === 'hi'
              ? 'होम स्क्रीन पर जोड़ें (Web App Install)'
              : 'Install Progressive Web App (PWA)'}
          </button>
        </div>

        {downloadStarted && (
          <div className="mt-3 p-2.5 bg-emerald-950/60 rounded-xl border border-emerald-500/30 text-[11px] text-emerald-300 flex items-center justify-center gap-2">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>PayBharat_v2.4_Official.apk downloaded to your device!</span>
          </div>
        )}

        <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-500 flex items-center justify-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Google Play Protect & Antivirus Certified</span>
        </div>
      </div>
    </div>
  );
};
