/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Fingerprint,
  X,
  Building2,
  CheckCircle2,
  AlertCircle,
  FileText,
  Download,
  Printer,
  Sparkles,
  RefreshCw,
  CreditCard,
  Banknote,
  ShieldCheck,
} from 'lucide-react';
import { AePSService, Language, Transaction } from '../types';
import { AEPS_BANKS } from '../data/mockData';
import { TRANSLATIONS } from '../utils/translations';
import { formatINR, downloadReceiptAsImage } from '../utils/receiptGenerator';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onSuccessTransaction: (txn: Transaction) => void;
}

export const AadhaarAePSModal: React.FC<Props> = ({
  isOpen,
  onClose,
  language,
  onSuccessTransaction,
}) => {
  const t = TRANSLATIONS[language];
  const [activeTab, setActiveTab] = useState<AePSService>('withdrawal');
  const [selectedBank, setSelectedBank] = useState<string>(AEPS_BANKS[0]);
  const [aadhaarNumber, setAadhaarNumber] = useState<string>('');
  const [customerMobile, setCustomerMobile] = useState<string>('9792621480');
  const [withdrawalAmount, setWithdrawalAmount] = useState<number>(1000);
  const [biometricDevice, setBiometricDevice] = useState<'Mantra MFS100' | 'Morpho MSO1300' | 'Startek FM220'>('Mantra MFS100');

  // Scanner status
  const [scanState, setScanState] = useState<'idle' | 'scanning' | 'success' | 'error'>('idle');
  const [qualityScore, setQualityScore] = useState<number>(0);
  const [completedTxn, setCompletedTxn] = useState<Transaction | null>(null);
  const [miniStatementResult, setMiniStatementResult] = useState<Array<{ date: string; narration: string; amount: string; type: 'CR' | 'DR' }> | null>(null);
  const [balanceResult, setBalanceResult] = useState<number | null>(null);

  if (!isOpen) return null;

  // Format Aadhaar with spaces (XXXX XXXX XXXX)
  const handleAadhaarChange = (val: string) => {
    const raw = val.replace(/\D/g, '').slice(0, 12);
    setAadhaarNumber(raw);
  };

  const getFormattedAadhaar = () => {
    if (!aadhaarNumber) return '';
    return aadhaarNumber.replace(/(\d{4})(\d{0,4})(\d{0,4})/, (_, p1, p2, p3) => {
      let res = p1;
      if (p2) res += ' ' + p2;
      if (p3) res += ' ' + p3;
      return res;
    });
  };

  const handleStartBiometricScan = () => {
    if (aadhaarNumber.length < 12) {
      alert('Please enter a valid 12-digit Aadhaar number');
      return;
    }
    setScanState('scanning');
    setQualityScore(0);

    // Simulate biometric capture optical pulse
    let currentQ = 0;
    const interval = setInterval(() => {
      currentQ += 15;
      if (currentQ <= 94) {
        setQualityScore(currentQ);
      }
    }, 120);

    setTimeout(() => {
      clearInterval(interval);
      setQualityScore(96);
      setScanState('success');

      // Process transaction based on tab
      if (activeTab === 'withdrawal' || activeTab === 'aadhaar_pay') {
        const cashbackPct = 0.035; // 3.5% instant agent cashback
        const cashbackAmt = Number((withdrawalAmount * cashbackPct).toFixed(2));
        const newTxn: Transaction = {
          id: `AEPS-${Date.now().toString().slice(-8)}`,
          type: activeTab === 'withdrawal' ? 'aeps_withdrawal' : 'aeps_aadhaar_pay',
          title: activeTab === 'withdrawal' ? `AePS Cash Withdrawal (${selectedBank.split(' ')[0]})` : `Aadhaar Pay Merchant Sale`,
          recipientName: `Customer Aadhaar: •••• ${aadhaarNumber.slice(-4)}`,
          recipientInfo: selectedBank,
          amount: withdrawalAmount,
          cashbackRate: cashbackPct,
          cashbackAmount: cashbackAmt,
          status: 'SUCCESS',
          timestamp: 'Just now',
          utrNumber: `RRN${Math.floor(100000000000 + Math.random() * 900000000000)}`,
          paymentMethod: `AePS Bio-Metric (${biometricDevice})`,
          category: 'Aadhaar ATM',
        };
        setCompletedTxn(newTxn);
        onSuccessTransaction(newTxn);
      } else if (activeTab === 'balance') {
        setBalanceResult(28450.0);
      } else if (activeTab === 'mini_statement') {
        setMiniStatementResult([
          { date: '28 Oct', narration: 'UPI/Sharma Grocery/P2M', amount: '₹140.00', type: 'DR' },
          { date: '27 Oct', narration: 'Salary Credit / NEFT', amount: '₹28,500.00', type: 'CR' },
          { date: '25 Oct', narration: 'Electricity Discom Bill', amount: '₹1,840.00', type: 'DR' },
          { date: '24 Oct', narration: 'AePS Cash Withdrawal', amount: '₹2,000.00', type: 'DR' },
          { date: '21 Oct', narration: 'Interest Credited Q3', amount: '₹342.50', type: 'CR' },
        ]);
      }
    }, 1800);
  };

  const handleReset = () => {
    setScanState('idle');
    setCompletedTxn(null);
    setMiniStatementResult(null);
    setBalanceResult(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 text-white shadow-2xl my-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center shadow-lg shadow-orange-500/20">
              <Fingerprint className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                {language === 'hi' ? 'आधार एटीएम (AePS)' : 'Aadhaar ATM (AePS)'}
                <span className="text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  NPCI Certified
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                {language === 'hi'
                  ? 'अंगूठे के निशान से नकद निकासी, बैलेंस पूछताछ एवं 2-5% तुरंत कैशबैक'
                  : 'Cash withdrawal, Balance check & guaranteed 2-5% instant cashback'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="grid grid-cols-4 gap-1 p-1 bg-slate-950/80 rounded-2xl border border-slate-800 mb-5">
          {[
            { id: 'withdrawal', label: language === 'hi' ? 'नकद निकासी' : 'Withdrawal', icon: Banknote },
            { id: 'balance', label: language === 'hi' ? 'बैलेंस जांच' : 'Balance', icon: CreditCard },
            { id: 'mini_statement', label: language === 'hi' ? 'मिनी स्टेटमेंट' : 'Mini Stmt', icon: FileText },
            { id: 'aadhaar_pay', label: language === 'hi' ? 'आधार पे' : 'Aadhaar Pay', icon: ShieldCheck },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as AePSService);
                  handleReset();
                }}
                className={`py-2 px-1 text-center rounded-xl text-xs font-semibold transition-all flex flex-col items-center gap-1 ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="truncate w-full">{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Success result view */}
        {completedTxn ? (
          <div className="bg-slate-950 rounded-2xl p-5 border border-emerald-500/30 text-center space-y-4">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center border border-emerald-500/40">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div>
              <span className="text-xs uppercase tracking-wider text-emerald-400 font-semibold">
                {language === 'hi' ? 'लेन-देन सफल रहा!' : 'Transaction Successful!'}
              </span>
              <div className="text-3xl font-mono font-bold text-white mt-1">
                {formatINR(completedTxn.amount)}
              </div>
              <p className="text-xs text-slate-400 mt-1">
                {completedTxn.title} · {selectedBank}
              </p>
            </div>

            {/* Instant Cashback Badge */}
            <div className="p-3 bg-emerald-950/40 rounded-xl border border-emerald-500/40 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-emerald-300 font-semibold">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>Instant 3.5% AePS Cashback Credited</span>
              </div>
              <span className="font-mono font-bold text-emerald-400 text-sm">
                +{formatINR(completedTxn.cashbackAmount)}
              </span>
            </div>

            {/* Reference info */}
            <div className="text-left text-xs bg-slate-900 rounded-xl p-3 space-y-1.5 border border-slate-800 text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-500">RRN / Auth Code:</span>
                <span className="font-mono">{completedTxn.utrNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Customer Aadhaar:</span>
                <span className="font-mono">XXXX-XXXX-{aadhaarNumber.slice(-4)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Biometric Device:</span>
                <span>{biometricDevice} (UIDAI Certified)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Date & Time:</span>
                <span>{new Date().toLocaleString('en-IN')}</span>
              </div>
            </div>

            {/* Action buttons: Download & Print Receipt */}
            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => downloadReceiptAsImage(completedTxn)}
                className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-md transition-colors"
              >
                <Download className="w-4 h-4" />
                {language === 'hi' ? 'रसीद डाउनलोड (PNG)' : 'Download Slip (PNG)'}
              </button>
              <button
                onClick={() => window.print()}
                className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-1.5 border border-slate-700 transition-colors"
              >
                <Printer className="w-4 h-4" />
                {language === 'hi' ? 'प्रिंट रसीद' : 'Print Slip'}
              </button>
            </div>

            <button
              onClick={handleReset}
              className="text-xs text-blue-400 hover:underline inline-block pt-1"
            >
              ← {language === 'hi' ? 'नया AePS लेन-देन करें' : 'Do another AePS transaction'}
            </button>
          </div>
        ) : balanceResult !== null ? (
          /* Balance Enquiry Result View */
          <div className="bg-slate-950 rounded-2xl p-5 border border-blue-500/30 text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-blue-500/20 text-blue-400 mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <div>
              <span className="text-xs uppercase text-slate-400 font-medium">Available Account Balance</span>
              <div className="text-3xl font-mono font-bold text-emerald-400 mt-1">
                {formatINR(balanceResult)}
              </div>
              <p className="text-xs text-slate-400 mt-1">
                {selectedBank} · Aadhaar XXXX-XXXX-{aadhaarNumber.slice(-4)}
              </p>
            </div>
            <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 text-xs text-slate-400 flex justify-between">
              <span>NPCI Ledger Status</span>
              <span className="text-emerald-400 font-semibold">Active / KYC Completed</span>
            </div>
            <button
              onClick={handleReset}
              className="w-full py-2.5 rounded-xl bg-slate-800 text-white text-xs font-semibold hover:bg-slate-700"
            >
              Done
            </button>
          </div>
        ) : miniStatementResult !== null ? (
          /* Mini Statement Result View */
          <div className="bg-slate-950 rounded-2xl p-4 border border-blue-500/30 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Mini Statement (Last 5 Transactions)
              </span>
              <span className="text-[11px] font-mono text-slate-400">{selectedBank.split(' ')[0]}</span>
            </div>
            <div className="divide-y divide-slate-800/80 text-xs">
              {miniStatementResult.map((item, idx) => (
                <div key={idx} className="py-2 flex items-center justify-between">
                  <div>
                    <div className="text-slate-200 font-medium">{item.narration}</div>
                    <div className="text-[10px] text-slate-500">{item.date}</div>
                  </div>
                  <div
                    className={`font-mono font-bold ${
                      item.type === 'CR' ? 'text-emerald-400' : 'text-red-400'
                    }`}
                  >
                    {item.type === 'CR' ? '+' : '-'} {item.amount}
                  </div>
                </div>
              ))}
            </div>
            <button
              onClick={() => window.print()}
              className="w-full py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              Print Mini Statement
            </button>
            <button
              onClick={handleReset}
              className="w-full text-center text-xs text-slate-400 hover:text-white"
            >
              Close Statement
            </button>
          </div>
        ) : (
          /* Normal Input Form */
          <div className="space-y-4">
            {/* Select Bank */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1.5 flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-blue-400" />
                {language === 'hi' ? 'ग्राहक का बैंक चुनें' : 'Select Customer Bank'}
              </label>
              <select
                value={selectedBank}
                onChange={(e) => setSelectedBank(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-blue-500"
              >
                {AEPS_BANKS.map((bank) => (
                  <option key={bank} value={bank}>
                    {bank}
                  </option>
                ))}
              </select>
            </div>

            {/* Aadhaar Number */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <CreditCard className="w-3.5 h-3.5 text-blue-400" />
                  {language === 'hi' ? '12 अंकों का आधार कार्ड नंबर' : '12-Digit Aadhaar Card Number'}
                </label>
                <span className="text-[11px] text-slate-500 font-mono">
                  {aadhaarNumber.length}/12
                </span>
              </div>
              <div className="relative">
                <input
                  type="text"
                  inputMode="numeric"
                  placeholder="e.g. 5482 9182 9262"
                  value={getFormattedAadhaar()}
                  onChange={(e) => handleAadhaarChange(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm font-mono tracking-widest text-white placeholder-slate-600 focus:outline-none focus:border-blue-500"
                />
                <button
                  type="button"
                  onClick={() => setAadhaarNumber('979262148092')}
                  className="absolute right-2 top-2 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-blue-400 rounded-lg text-[10px] font-semibold transition-colors"
                >
                  Quick Fill
                </button>
              </div>
            </div>

            {/* Customer Mobile */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                {language === 'hi' ? 'ग्राहक का मोबाइल नंबर (SMS रसीद हेतु)' : 'Customer Mobile (For SMS Receipt)'}
              </label>
              <input
                type="tel"
                value={customerMobile}
                onChange={(e) => setCustomerMobile(e.target.value)}
                placeholder="10 digit mobile"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Amount (if withdrawal or aadhaar pay) */}
            {(activeTab === 'withdrawal' || activeTab === 'aadhaar_pay') && (
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-slate-300">
                    {language === 'hi' ? 'निकासी राशि (₹)' : 'Withdrawal Amount (₹)'}
                  </label>
                  <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> 3.5% Instant Cashback: +₹{(withdrawalAmount * 0.035).toFixed(1)}
                  </span>
                </div>
                <div className="relative mb-2">
                  <span className="absolute left-3.5 top-2.5 text-slate-400 font-mono font-bold">₹</span>
                  <input
                    type="number"
                    value={withdrawalAmount || ''}
                    onChange={(e) => setWithdrawalAmount(Number(e.target.value))}
                    min={100}
                    max={10000}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-4 py-2.5 text-sm font-mono font-bold text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div className="flex gap-1.5">
                  {[500, 1000, 2000, 3000, 5000].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setWithdrawalAmount(preset)}
                      className={`flex-1 py-1 text-[11px] font-semibold rounded-lg border transition-colors ${
                        withdrawalAmount === preset
                          ? 'border-blue-500 bg-blue-500/20 text-blue-300'
                          : 'border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      ₹{preset}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Biometric Device Selector */}
            <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-semibold text-slate-300">
                  {language === 'hi' ? 'बायोमेट्रिक फिंगरप्रिंट स्कैनर' : 'Biometric Fingerprint Scanner'}
                </span>
                <span className="text-emerald-400 text-[10px] font-medium">Device Ready</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {(['Mantra MFS100', 'Morpho MSO1300', 'Startek FM220'] as const).map((dev) => (
                  <button
                    key={dev}
                    type="button"
                    onClick={() => setBiometricDevice(dev)}
                    className={`py-1.5 px-2 rounded-xl text-[11px] font-medium border text-center transition-all ${
                      biometricDevice === dev
                        ? 'border-blue-500 bg-blue-600/20 text-blue-300'
                        : 'border-slate-800 text-slate-500 hover:text-slate-300'
                    }`}
                  >
                    {dev}
                  </button>
                ))}
              </div>
            </div>

            {/* Interactive Biometric Sensor Touch Area */}
            <div
              onClick={scanState === 'idle' ? handleStartBiometricScan : undefined}
              className={`relative border-2 border-dashed rounded-3xl p-6 text-center cursor-pointer select-none transition-all ${
                scanState === 'scanning'
                  ? 'border-emerald-500 bg-emerald-950/20 animate-pulse'
                  : 'border-slate-700 bg-slate-950 hover:border-blue-500 hover:bg-slate-900/60'
              }`}
            >
              {/* Laser scanning line effect */}
              {scanState === 'scanning' && (
                <div className="absolute inset-x-8 top-4 h-1 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-lg shadow-emerald-400 animate-bounce" />
              )}

              <div
                className={`w-16 h-16 rounded-full mx-auto flex items-center justify-center transition-all duration-300 ${
                  scanState === 'scanning'
                    ? 'bg-emerald-500/20 text-emerald-400 scale-110 shadow-lg shadow-emerald-500/30'
                    : 'bg-slate-800 text-slate-400 hover:text-blue-400'
                }`}
              >
                <Fingerprint className="w-10 h-10" />
              </div>

              <div className="mt-3">
                <span className="text-xs font-bold text-white block">
                  {scanState === 'scanning'
                    ? language === 'hi'
                      ? 'अंगूठे का निशान पढ़ा जा रहा है...'
                      : 'Scanning Fingerprint Biometrics...'
                    : language === 'hi'
                    ? 'बायोमेट्रिक स्कैन के लिए यहाँ दबाएँ'
                    : 'Tap Fingerprint Sensor to Authenticate'}
                </span>
                <span className="text-[11px] text-slate-400">
                  {scanState === 'scanning'
                    ? `UIDAI Quality Match: ${qualityScore}%`
                    : `${biometricDevice} (RD Service Active)`}
                </span>
              </div>
            </div>

            {/* Submit Action */}
            <button
              onClick={handleStartBiometricScan}
              disabled={scanState === 'scanning'}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 active:scale-[0.98] transition-all disabled:opacity-50"
            >
              {scanState === 'scanning' ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Verifying Aadhaar Fingerprint...
                </>
              ) : (
                <>
                  <Fingerprint className="w-4 h-4" />
                  {language === 'hi' ? 'आधार बायोमेट्रिक सत्यापन करें' : 'Authorize with Aadhaar Biometric'}
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
