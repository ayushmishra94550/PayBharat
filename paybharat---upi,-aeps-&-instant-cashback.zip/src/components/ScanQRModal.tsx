/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  QrCode,
  X,
  Camera,
  Upload,
  Copy,
  Check,
  Download,
  Share2,
  Sparkles,
  ShieldCheck,
  ArrowRight,
  Store,
} from 'lucide-react';
import { Language, Transaction, UserProfile } from '../types';
import { PRESET_MERCHANTS_QR } from '../data/mockData';
import { formatINR } from '../utils/receiptGenerator';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  user: UserProfile;
  onSuccessPayment: (txn: Transaction) => void;
}

export const ScanQRModal: React.FC<Props> = ({
  isOpen,
  onClose,
  language,
  user,
  onSuccessPayment,
}) => {
  const [activeTab, setActiveTab] = useState<'scan' | 'my_qr'>('scan');
  const [selectedMerchant, setSelectedMerchant] = useState(PRESET_MERCHANTS_QR[0]);
  const [payAmount, setPayAmount] = useState<number>(selectedMerchant.defaultAmount);
  const [cameraActive, setCameraActive] = useState(false);
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    if (isOpen && activeTab === 'scan' && cameraActive) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, activeTab, cameraActive]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.warn('Camera access denied or unavailable in iframe:', err);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
      videoRef.current.srcObject = null;
    }
  };

  if (!isOpen) return null;

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(user.upiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  const handlePayMerchant = () => {
    if (!payAmount || payAmount <= 0) return;
    setIsProcessing(true);

    setTimeout(() => {
      setIsProcessing(false);
      const cashbackRate = selectedMerchant.cashbackPercent / 100;
      const cashbackAmount = Number((payAmount * cashbackRate).toFixed(2));

      const newTxn: Transaction = {
        id: `QR-${Date.now().toString().slice(-8)}`,
        type: 'send_money',
        title: `Paid to ${selectedMerchant.name}`,
        recipientName: selectedMerchant.name,
        recipientInfo: selectedMerchant.vpa,
        amount: payAmount,
        cashbackRate,
        cashbackAmount,
        status: 'SUCCESS',
        timestamp: 'Just now',
        utrNumber: `UTR${Math.floor(100000000000 + Math.random() * 900000000000)}`,
        paymentMethod: 'UPI Linked SBI Account',
        category: 'QR Merchant Pay',
        scratched: false,
      };

      onSuccessPayment(newTxn);
      onClose();
    }, 1200);
  };

  const downloadMyQrImage = () => {
    // Generate simple SVG QR as download
    const svgData = `
      <svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400">
        <rect width="100%" height="100%" fill="#ffffff"/>
        <rect x="20" y="20" width="360" height="360" rx="16" fill="#f8fafc" stroke="#cbd5e1" stroke-width="2"/>
        <text x="200" y="60" font-family="sans-serif" font-size="18" font-weight="bold" fill="#0f172a" text-anchor="middle">Pay to ${user.name}</text>
        <text x="200" y="85" font-family="monospace" font-size="14" fill="#64748b" text-anchor="middle">${user.upiId}</text>
        <g transform="translate(70, 110)">
          <!-- Simulated crisp QR pattern -->
          <rect x="0" y="0" width="70" height="70" fill="#0f172a" rx="8"/>
          <rect x="10" y="10" width="50" height="50" fill="#ffffff" rx="4"/>
          <rect x="20" y="20" width="30" height="30" fill="#0f172a" rx="2"/>
          <rect x="190" y="0" width="70" height="70" fill="#0f172a" rx="8"/>
          <rect x="200" y="10" width="50" height="50" fill="#ffffff" rx="4"/>
          <rect x="210" y="20" width="30" height="30" fill="#0f172a" rx="2"/>
          <rect x="0" y="190" width="70" height="70" fill="#0f172a" rx="8"/>
          <rect x="10" y="200" width="50" height="50" fill="#ffffff" rx="4"/>
          <rect x="20" y="210" width="30" height="30" fill="#0f172a" rx="2"/>
          <circle cx="130" cy="130" r="30" fill="#3b82f6"/>
          <text x="130" y="137" font-family="sans-serif" font-size="20" font-weight="bold" fill="#ffffff" text-anchor="middle">₹</text>
        </g>
        <text x="200" y="360" font-family="sans-serif" font-size="12" fill="#10b981" font-weight="bold" text-anchor="middle">⚡ Guaranteed 2%-5% Cashback via PayBharat</text>
      </svg>
    `;
    const blob = new Blob([svgData], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `PayBharat_QR_${user.name.replace(/\s+/g, '_')}.svg`;
    a.click();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 text-white shadow-2xl my-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-600/20 text-blue-400 flex items-center justify-center">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                {language === 'hi' ? 'क्यूआर स्कैन एवं भुगतान' : 'Scan & Pay Any QR'}
              </h2>
              <p className="text-xs text-slate-400">
                {language === 'hi'
                  ? 'किसी भी क्यूआर पर 2% से 5% तुरंत कैशबैक'
                  : 'Pay any UPI QR & earn guaranteed 2% - 5% cashback'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="grid grid-cols-2 gap-1 p-1 bg-slate-950 rounded-xl border border-slate-800 mb-4">
          <button
            onClick={() => setActiveTab('scan')}
            className={`py-2 text-xs font-semibold rounded-lg transition-all ${
              activeTab === 'scan' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            {language === 'hi' ? 'क्यूआर स्कैन करें' : 'Scan Merchant QR'}
          </button>
          <button
            onClick={() => setActiveTab('my_qr')}
            className={`py-2 text-xs font-semibold rounded-lg transition-all ${
              activeTab === 'my_qr' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            {language === 'hi' ? 'मेरा क्यूआर कोड' : 'My Receiving QR'}
          </button>
        </div>

        {activeTab === 'scan' ? (
          <div>
            {/* Viewfinder box */}
            <div className="relative aspect-square max-h-56 mx-auto bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden flex flex-col items-center justify-center mb-4">
              {cameraActive ? (
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="text-center p-4">
                  <div className="w-12 h-12 rounded-full bg-slate-900 mx-auto flex items-center justify-center text-slate-400 mb-2 border border-slate-800">
                    <Camera className="w-6 h-6" />
                  </div>
                  <button
                    onClick={() => setCameraActive(true)}
                    className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-xs font-medium text-white shadow-md transition-colors"
                  >
                    {language === 'hi' ? 'कैमरा चालू करें' : 'Enable Live Camera'}
                  </button>
                  <p className="text-[11px] text-slate-500 mt-2">
                    or choose a merchant preset below
                  </p>
                </div>
              )}

              {/* Scanning laser line overlay */}
              <div className="absolute inset-x-6 top-1/2 h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-lg shadow-emerald-400 animate-pulse" />

              {/* Viewfinder corner brackets */}
              <div className="absolute top-4 left-4 w-6 h-6 border-t-2 border-l-2 border-emerald-400" />
              <div className="absolute top-4 right-4 w-6 h-6 border-t-2 border-r-2 border-emerald-400" />
              <div className="absolute bottom-4 left-4 w-6 h-6 border-b-2 border-l-2 border-emerald-400" />
              <div className="absolute bottom-4 right-4 w-6 h-6 border-b-2 border-r-2 border-emerald-400" />
            </div>

            {/* Merchant Presets */}
            <div className="mb-4">
              <label className="text-xs font-semibold text-slate-300 block mb-1.5 flex items-center justify-between">
                <span>{language === 'hi' ? 'दुकानदार / मर्चेंट चुनें' : 'Select Scanned Merchant:'}</span>
                <span className="text-emerald-400 font-mono text-[11px]">
                  +{selectedMerchant.cashbackPercent}% Cashback
                </span>
              </label>
              <div className="grid grid-cols-1 gap-1.5 max-h-36 overflow-y-auto pr-1">
                {PRESET_MERCHANTS_QR.map((m) => (
                  <button
                    key={m.vpa}
                    type="button"
                    onClick={() => {
                      setSelectedMerchant(m);
                      setPayAmount(m.defaultAmount);
                    }}
                    className={`p-2 rounded-xl text-left border flex items-center justify-between transition-all ${
                      selectedMerchant.vpa === m.vpa
                        ? 'border-blue-500 bg-blue-950/40 text-white'
                        : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <Store className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                      <div className="truncate">
                        <div className="text-xs font-semibold text-slate-200 truncate">{m.name}</div>
                        <div className="text-[10px] text-slate-500 font-mono">{m.vpa}</div>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-emerald-400 shrink-0 ml-2">
                      {m.cashbackPercent}% Back
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Amount input */}
            <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 mb-4">
              <div className="flex items-center justify-between mb-1 text-xs">
                <span className="text-slate-400">{language === 'hi' ? 'भुगतान राशि:' : 'Payment Amount:'}</span>
                <span className="text-emerald-400 font-semibold flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  +₹{((payAmount * selectedMerchant.cashbackPercent) / 100).toFixed(2)} Instant Cashback
                </span>
              </div>
              <div className="relative">
                <span className="absolute left-3 top-2.5 font-bold font-mono text-slate-400">₹</span>
                <input
                  type="number"
                  value={payAmount || ''}
                  onChange={(e) => setPayAmount(Number(e.target.value))}
                  min={1}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-8 pr-4 py-2 text-base font-bold font-mono text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            {/* Pay Button */}
            <button
              onClick={handlePayMerchant}
              disabled={isProcessing || !payAmount || payAmount <= 0}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-600 to-emerald-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 active:scale-[0.98] transition-all disabled:opacity-50"
            >
              {isProcessing ? (
                'Completing Payment...'
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  {language === 'hi'
                    ? `₹${payAmount} का भुगतान करें एवं कैशबैक पाएँ`
                    : `Pay ${formatINR(payAmount)} & Claim Cashback`}
                  <ArrowRight className="w-4 h-4 ml-1" />
                </>
              )}
            </button>
          </div>
        ) : (
          /* My Receiving QR */
          <div className="text-center space-y-4">
            <div className="bg-white p-5 rounded-2xl max-w-[260px] mx-auto shadow-xl">
              <div className="text-slate-900 font-bold text-sm mb-1">{user.name}</div>
              <div className="text-slate-500 text-[11px] font-mono mb-3">{user.upiId}</div>

              {/* Graphic QR */}
              <div className="aspect-square bg-slate-100 rounded-xl p-3 border border-slate-200 flex flex-col items-center justify-center relative">
                <div className="grid grid-cols-6 gap-1 w-full h-full opacity-90 p-2">
                  {Array.from({ length: 36 }).map((_, i) => (
                    <div
                      key={i}
                      className={`rounded-sm ${
                        [0, 1, 4, 5, 6, 7, 10, 11, 14, 19, 21, 24, 25, 28, 29, 30, 31, 34, 35].includes(i)
                          ? 'bg-slate-900'
                          : i % 2 === 0
                          ? 'bg-slate-800'
                          : 'bg-transparent'
                      }`}
                    />
                  ))}
                </div>
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="w-9 h-9 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center shadow-lg text-sm">
                    ₹
                  </div>
                </div>
              </div>

              <div className="text-[10px] text-emerald-600 font-bold mt-3">
                ⚡ Any UPI app can scan & pay
              </div>
            </div>

            {/* Copy UPI ID */}
            <div className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs">
              <span className="font-mono text-slate-300">{user.upiId}</span>
              <button
                onClick={handleCopyUpi}
                className="text-blue-400 hover:text-blue-300 font-semibold flex items-center gap-1"
              >
                {copiedUpi ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" /> Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" /> Copy
                  </>
                )}
              </button>
            </div>

            {/* Download & Share QR */}
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={downloadMyQrImage}
                className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-md"
              >
                <Download className="w-4 h-4" />
                {language === 'hi' ? 'क्यूआर डाउनलोड करें' : 'Download QR'}
              </button>
              <button
                onClick={() => {
                  if (navigator.share) {
                    navigator.share({
                      title: `Pay to ${user.name}`,
                      text: `Pay me via UPI: ${user.upiId}`,
                    }).catch(() => {});
                  } else {
                    handleCopyUpi();
                  }
                }}
                className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 border border-slate-700"
              >
                <Share2 className="w-4 h-4" />
                {language === 'hi' ? 'शेयर करें' : 'Share QR'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
