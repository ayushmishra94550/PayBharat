/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  QrCode,
  Smartphone,
  Zap,
  Fingerprint,
  Users,
  Building,
  ArrowLeftRight,
  Sparkles,
  Volume2,
  FileSpreadsheet,
  Plus,
  ShieldCheck,
  ChevronRight,
  TrendingUp,
  Download,
  Share2,
  Gift,
  Car,
  Tv,
  Flame,
  Droplet,
  Wifi,
  CreditCard,
  CheckCircle2,
  RotateCcw,
  Globe,
  SmartphoneNfc,
  Monitor,
  ArrowRight,
} from 'lucide-react';

import {
  BillCategory,
  Language,
  SoundboxConfig,
  Transaction,
  UserProfile,
} from './types';
import {
  INITIAL_BANKS,
  INITIAL_TRANSACTIONS,
  INITIAL_USER,
} from './data/mockData';
import { TRANSLATIONS } from './utils/translations';
import { formatINR, downloadReceiptAsImage } from './utils/receiptGenerator';
import { speakSoundboxAlert } from './utils/audioAlert';

import { ScanQRModal } from './components/ScanQRModal';
import { SendMoneyModal } from './components/SendMoneyModal';
import { AadhaarAePSModal } from './components/AadhaarAePSModal';
import { RechargeModal } from './components/RechargeModal';
import { BillPayModal } from './components/BillPayModal';
import { SoundboxModal } from './components/SoundboxModal';
import { ReceiptModal } from './components/ReceiptModal';
import { ScratchCardModal } from './components/ScratchCardModal';
import { PassbookDrawer } from './components/PassbookDrawer';
import { CashbackRewardsHub } from './components/CashbackRewardsHub';
import { SecurityPinModal } from './components/SecurityPinModal';
import { DownloadCenterModal } from './components/DownloadCenterModal';
import { DownloadAppModal } from './components/DownloadAppModal';
import { ReferEarnModal } from './components/ReferEarnModal';

export default function App() {
  const [language, setLanguage] = useState<Language>('hi');
  const [user, setUser] = useState<UserProfile>(INITIAL_USER);
  const [banks, setBanks] = useState(INITIAL_BANKS);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [isMobileFrameMode, setIsMobileFrameMode] = useState<boolean>(false);

  // Soundbox settings
  const [soundboxConfig, setSoundboxConfig] = useState<SoundboxConfig>({
    enabled: true,
    volume: 1,
    language: 'hi',
  });

  // Modal Controls
  const [isScanOpen, setIsScanOpen] = useState(false);
  const [sendMoneyMode, setSendMoneyMode] = useState<'mobile' | 'bank' | 'self' | 'check_balance' | null>(null);
  const [isAePSOpen, setIsAePSOpen] = useState(false);
  const [isRechargeOpen, setIsRechargeOpen] = useState(false);
  const [billCategory, setBillCategory] = useState<BillCategory | null>(null);
  const [isSoundboxOpen, setIsSoundboxOpen] = useState(false);
  const [isPassbookOpen, setIsPassbookOpen] = useState(false);
  const [isCashbackHubOpen, setIsCashbackHubOpen] = useState(false);
  const [isDownloadCenterOpen, setIsDownloadCenterOpen] = useState(false);
  const [isDownloadAppOpen, setIsDownloadAppOpen] = useState(false);
  const [isReferEarnOpen, setIsReferEarnOpen] = useState(false);
  const [activeReceiptTxn, setActiveReceiptTxn] = useState<Transaction | null>(null);
  const [activeScratchTxn, setActiveScratchTxn] = useState<Transaction | null>(null);
  const [isAddMoneyOpen, setIsAddMoneyOpen] = useState(false);
  const [addAmount, setAddAmount] = useState<number>(1000);

  // Security Verification state for Send Money and AePS
  const [pendingSecureAction, setPendingSecureAction] = useState<{
    type: 'send_money' | 'aeps';
    mode?: 'mobile' | 'bank' | 'self' | 'check_balance';
    label: string;
  } | null>(null);

  const requestOpenSendMoney = (mode: 'mobile' | 'bank' | 'self' | 'check_balance') => {
    setPendingSecureAction({
      type: 'send_money',
      mode,
      label: language === 'hi' ? 'यूपीआई भुगतान' : 'Send Money',
    });
  };

  const requestOpenAePS = () => {
    setPendingSecureAction({
      type: 'aeps',
      label: language === 'hi' ? 'आधार एटीएम (AePS)' : 'Aadhaar ATM (AePS)',
    });
  };

  const handleSecuritySuccess = () => {
    if (!pendingSecureAction) return;
    if (pendingSecureAction.type === 'send_money') {
      setSendMoneyMode(pendingSecureAction.mode || 'mobile');
    } else if (pendingSecureAction.type === 'aeps') {
      setIsAePSOpen(true);
    }
    setPendingSecureAction(null);
  };

  const t = TRANSLATIONS[language];

  // Callback when any payment or recharge completes
  const handlePaymentSuccess = (newTxn: Transaction) => {
    // 1. Add to transactions list
    setTransactions((prev) => [newTxn, ...prev]);

    // 2. Add cashback to wallet & lifetime stats
    setUser((prev) => ({
      ...prev,
      walletBalance: prev.walletBalance + newTxn.cashbackAmount,
      cashbackBalance: prev.cashbackBalance + newTxn.cashbackAmount,
      totalCashbackLifetime: prev.totalCashbackLifetime + newTxn.cashbackAmount,
    }));

    // 3. Trigger Soundbox voice notification if enabled
    if (soundboxConfig.enabled) {
      speakSoundboxAlert(newTxn.amount, soundboxConfig.language, newTxn.cashbackAmount);
    }

    // 4. Open Receipt & Scratch card
    setActiveReceiptTxn(newTxn);
  };

  // Callback when referral reward is claimed
  const handleReferralRewardClaimed = (amount: number, friendName: string) => {
    setUser((prev) => ({
      ...prev,
      walletBalance: prev.walletBalance + amount,
      cashbackBalance: prev.cashbackBalance + amount,
      totalCashbackLifetime: prev.totalCashbackLifetime + amount,
    }));

    const refTxn: Transaction = {
      id: `REF-${Date.now().toString().slice(-8)}`,
      type: 'cashback_credit',
      title: `Referral Reward (${friendName})`,
      recipientName: `Friend Joined: ${friendName}`,
      recipientInfo: 'PayBharat Refer & Earn Program',
      amount: amount,
      cashbackRate: 1.0,
      cashbackAmount: amount,
      status: 'SUCCESS',
      timestamp: 'Just now',
      utrNumber: `REF${Math.floor(100000000000 + Math.random() * 900000000000)}`,
      paymentMethod: 'PayBharat Referral Incentive',
      category: 'Refer & Earn',
      scratched: true,
    };

    setTransactions((prev) => [refTxn, ...prev]);

    if (soundboxConfig.enabled) {
      speakSoundboxAlert(amount, soundboxConfig.language, amount);
    }
  };

  // Transfer cashback to primary bank
  const handleTransferCashback = (amt: number) => {
    setUser((prev) => ({
      ...prev,
      cashbackBalance: 0,
      walletBalance: Math.max(0, prev.walletBalance - amt),
    }));
    setBanks((prev) =>
      prev.map((b) => (b.isPrimary ? { ...b, balance: b.balance + amt } : b))
    );
  };

  // Add money to wallet
  const handleConfirmAddMoney = () => {
    if (addAmount <= 0) return;
    const cashbackPct = 0.02; // 2% bonus cashback on topup
    const bonus = Number((addAmount * cashbackPct).toFixed(2));

    setUser((prev) => ({
      ...prev,
      walletBalance: prev.walletBalance + addAmount + bonus,
      cashbackBalance: prev.cashbackBalance + bonus,
      totalCashbackLifetime: prev.totalCashbackLifetime + bonus,
    }));

    const topupTxn: Transaction = {
      id: `WALLET-${Date.now().toString().slice(-8)}`,
      type: 'cashback_credit',
      title: 'Wallet Top-up + 2% Bonus',
      recipientName: 'PayBharat Wallet',
      recipientInfo: user.phone,
      amount: addAmount,
      cashbackRate: cashbackPct,
      cashbackAmount: bonus,
      status: 'SUCCESS',
      timestamp: 'Just now',
      utrNumber: `UTR${Math.floor(100000000000 + Math.random() * 900000000000)}`,
      paymentMethod: 'SBI NetBanking / UPI',
      category: 'Wallet Load',
      scratched: true,
    };

    setTransactions((prev) => [topupTxn, ...prev]);
    setIsAddMoneyOpen(false);
    setActiveReceiptTxn(topupTxn);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 selection:bg-blue-500 selection:text-white">
      {/* Top Bar Contract (1 line brand, nav links, primary action) */}
      <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          {/* Zone 1: Brand Wordmark */}
          <div className="flex items-center gap-3">
            <a
              href="/"
              className="text-lg sm:text-xl font-bold tracking-tight text-white whitespace-nowrap flex items-center gap-2 group"
            >
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
                <span className="text-base font-black">₹</span>
              </div>
              <span className="bg-gradient-to-r from-white via-slate-100 to-blue-300 bg-clip-text text-transparent">
                PayBharat
              </span>
              <span className="text-[11px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20 hidden sm:inline-block">
                2% - 5% Cashback
              </span>
            </a>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-300">
            <button
              onClick={() => requestOpenSendMoney('mobile')}
              className="hover:text-white transition-colors whitespace-nowrap"
            >
              {language === 'hi' ? 'यूपीआई भुगतान' : 'UPI Transfer'}
            </button>
            <button
              onClick={() => requestOpenAePS()}
              className="hover:text-white transition-colors whitespace-nowrap flex items-center gap-1 text-amber-300"
            >
              <Fingerprint className="w-3.5 h-3.5" />
              {language === 'hi' ? 'आधार एटीएम' : 'AePS ATM'}
            </button>
            <button
              onClick={() => setIsRechargeOpen(true)}
              className="hover:text-white transition-colors whitespace-nowrap"
            >
              {language === 'hi' ? 'रिचार्ज एवं बिल' : 'Recharge & Bills'}
            </button>
            <button
              onClick={() => setIsCashbackHubOpen(true)}
              className="hover:text-emerald-400 transition-colors whitespace-nowrap flex items-center gap-1 text-emerald-300"
            >
              <Sparkles className="w-3.5 h-3.5" />
              {language === 'hi' ? 'कैशबैक हब (2-5%)' : 'Cashback Hub (2-5%)'}
            </button>
            <button
              onClick={() => setIsSoundboxOpen(true)}
              className="hover:text-white transition-colors whitespace-nowrap flex items-center gap-1 text-blue-300"
            >
              <Volume2 className="w-3.5 h-3.5" />
              {language === 'hi' ? 'स्मार्ट साउंडबॉक्स' : 'Smart Soundbox'}
            </button>
            <button
              onClick={() => setIsReferEarnOpen(true)}
              className="hover:text-amber-400 transition-colors whitespace-nowrap flex items-center gap-1 text-amber-300"
            >
              <Gift className="w-3.5 h-3.5" />
              {language === 'hi' ? 'रेफर एवं कमाएं (₹150)' : 'Refer & Earn (₹150)'}
            </button>
            <button
              onClick={() => setIsDownloadCenterOpen(true)}
              className="hover:text-white transition-colors whitespace-nowrap flex items-center gap-1 text-emerald-400"
            >
              <Download className="w-3.5 h-3.5" />
              {language === 'hi' ? 'डाउनलोड केंद्र' : 'Downloads'}
            </button>
          </nav>

          {/* Zone 3: Actions (Language toggle + Frame switcher + Download + Scan) */}
          <div className="flex items-center gap-2.5 shrink-0">
            {/* Download App Quick Button */}
            <button
              onClick={() => setIsDownloadAppOpen(true)}
              className="px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all"
              title="Download Android App / APK"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{language === 'hi' ? 'ऐप डाउनलोड' : 'Get App'}</span>
            </button>

            {/* Download Center Quick Button */}
            <button
              onClick={() => setIsDownloadCenterOpen(true)}
              className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-colors"
              title="Download Receipts & Statements"
            >
              <Download className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden sm:inline">{language === 'hi' ? 'डाउनलोड' : 'Downloads'}</span>
            </button>

            {/* Language Switcher */}
            <button
              onClick={() => setLanguage(language === 'hi' ? 'en' : 'hi')}
              className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-colors"
              title="Toggle Language"
            >
              <Globe className="w-3.5 h-3.5 text-blue-400" />
              <span>{language === 'hi' ? 'English' : 'हिंदी'}</span>
            </button>

            {/* Mobile / Desktop view switcher */}
            <button
              onClick={() => setIsMobileFrameMode(!isMobileFrameMode)}
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 transition-colors"
              title="Switch view framing"
            >
              {isMobileFrameMode ? (
                <>
                  <Monitor className="w-3.5 h-3.5 text-teal-400" />
                  <span>Desktop View</span>
                </>
              ) : (
                <>
                  <SmartphoneNfc className="w-3.5 h-3.5 text-teal-400" />
                  <span>Mobile View</span>
                </>
              )}
            </button>

            {/* Scan QR Primary Button */}
            <button
              onClick={() => setIsScanOpen(true)}
              className="px-3.5 py-2 text-xs font-bold text-slate-950 bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 rounded-xl flex items-center gap-1.5 shadow-md shadow-emerald-500/20 active:scale-95 transition-all whitespace-nowrap"
            >
              <QrCode className="w-4 h-4" />
              <span>{t.scanQr}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container - Supports full width or smartphone frame mode */}
      <main
        className={`mx-auto transition-all duration-300 ${
          isMobileFrameMode
            ? 'max-w-[430px] my-6 p-4 bg-slate-900 border-4 border-slate-800 rounded-[44px] shadow-2xl relative overflow-hidden'
            : 'max-w-6xl px-4 sm:px-6 py-6'
        }`}
      >
        {/* Mobile Frame Speaker / Notch in mobile mode */}
        {isMobileFrameMode && (
          <div className="flex items-center justify-between pb-3 px-2 border-b border-slate-800 text-[11px] text-slate-400">
            <span className="font-mono font-bold text-white">09:41</span>
            <div className="w-20 h-4 bg-black rounded-full" />
            <div className="flex items-center gap-1">
              <span>5G</span>
              <span>100%</span>
            </div>
          </div>
        )}

        {/* Guaranteed 2% to 5% Cashback Highlight Banner */}
        <div className="mb-6 p-4 rounded-3xl bg-gradient-to-r from-blue-900/60 via-indigo-900/40 to-slate-900 border border-blue-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xl">
          <div className="flex items-start sm:items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400/20 text-amber-300 flex items-center justify-center shrink-0 border border-amber-400/30">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-bold text-white flex items-center gap-2">
                <span>{t.cashbackBanner}</span>
                <span className="text-[10px] font-bold bg-amber-400/20 text-amber-300 px-2 py-0.5 rounded-full">
                  Guaranteed
                </span>
              </div>
              <div className="text-xs text-slate-300 mt-0.5">
                {language === 'hi'
                  ? 'मोबाइल रिचार्ज, बिजली बिल, फास्टैग, क्यूआर कोड और आधार एटीएम पर तुरंत कैशबैक'
                  : 'Instant cashback credited directly into your wallet on mobile recharges, utility bills & AePS'}
              </div>
            </div>
          </div>
          <button
            onClick={() => setIsCashbackHubOpen(true)}
            className="self-start sm:self-auto px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1 transition-all whitespace-nowrap shadow-md shadow-amber-500/20"
          >
            {language === 'hi' ? 'कैशबैक दरें देखें' : 'View Rates'}
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Section 1: Wallet & Bank Account Header Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {/* Card 1: Wallet Balance & Add Money */}
          <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-lg relative overflow-hidden flex flex-col justify-between">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-slate-400">{t.walletBalance}</span>
              <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                Active KYC
              </span>
            </div>
            <div>
              <div className="text-3xl font-mono font-bold text-white">
                {formatINR(user.walletBalance)}
              </div>
              <div className="text-xs text-slate-400 mt-1">
                Linked: <strong className="text-slate-300">{user.phone}</strong>
              </div>
            </div>
            <div className="flex items-center gap-2 mt-4 pt-3 border-t border-slate-800/80">
              <button
                onClick={() => setIsAddMoneyOpen(true)}
                className="flex-1 py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-md transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                {t.addMoney}
              </button>
              <button
                onClick={() => setIsPassbookOpen(true)}
                className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-semibold text-xs flex items-center justify-center gap-1.5 border border-slate-700 transition-colors"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                {t.passbook}
              </button>
            </div>
          </div>

          {/* Card 2: Instant Cashback Balance */}
          <div className="p-5 rounded-3xl bg-gradient-to-br from-emerald-950/50 via-slate-900 to-slate-900 border border-emerald-500/30 shadow-lg flex flex-col justify-between">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold text-emerald-300">{t.cashbackEarned}</span>
              </div>
              <span className="text-[11px] font-bold text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/30">
                {user.tier}
              </span>
            </div>
            <div>
              <div className="text-3xl font-mono font-bold text-emerald-400">
                {formatINR(user.cashbackBalance)}
              </div>
              <div className="text-xs text-slate-400 mt-1 flex items-center justify-between">
                <span>{t.lifetimeCashback}:</span>
                <span className="font-mono font-bold text-white">{formatINR(user.totalCashbackLifetime)}</span>
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-emerald-500/20 flex gap-2">
              <button
                onClick={() => setIsCashbackHubOpen(true)}
                className="w-full py-2 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-500/20 transition-all"
              >
                <Sparkles className="w-3.5 h-3.5" />
                {language === 'hi' ? 'कैशबैक बैंक में निकालें' : 'Withdraw Cashback'}
              </button>
            </div>
          </div>

          {/* Card 3: Smart Soundbox & UPI ID */}
          <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-lg flex flex-col justify-between">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-1.5">
                <Volume2 className="w-4 h-4 text-blue-400" />
                <span className="text-xs font-bold text-slate-300">{t.soundbox}</span>
              </div>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                soundboxConfig.enabled
                  ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}>
                {soundboxConfig.enabled ? 'ON · Hindi' : 'Muted'}
              </span>
            </div>
            <div>
              <div className="text-xs text-slate-400">Personal UPI VPA:</div>
              <div className="text-sm font-mono font-bold text-white truncate mt-0.5">
                {user.upiId}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                Linked Bank: <strong className="text-slate-300">SBI (•••• 4892)</strong>
              </div>
            </div>
            <div className="flex items-center gap-2 mt-4 pt-3 border-t border-slate-800/80">
              <button
                onClick={() => setIsSoundboxOpen(true)}
                className="flex-1 py-2 px-3 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 font-semibold text-xs flex items-center justify-center gap-1.5 border border-blue-500/30 transition-colors"
              >
                <Volume2 className="w-3.5 h-3.5" />
                {language === 'hi' ? 'साउंडबॉक्स टेस्ट' : 'Test Voice'}
              </button>
              <button
                onClick={() => requestOpenSendMoney('check_balance')}
                className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-semibold text-xs flex items-center justify-center gap-1.5 border border-slate-700 transition-colors"
              >
                {t.checkBalance}
              </button>
            </div>
          </div>
        </div>

        {/* Section 2: Core Payment Services (Transfer & AePS Aadhaar ATM) */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-3 px-1">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <span>{language === 'hi' ? 'धन अंतरण एवं आधार एटीएम' : 'Money Transfer & Aadhaar ATM'}</span>
              <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                Instant 2% - 5% Cashback
              </span>
            </h2>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {/* 1. Scan Any QR */}
            <button
              onClick={() => setIsScanOpen(true)}
              className="p-4 rounded-3xl bg-slate-900 border border-slate-800 hover:border-blue-500/50 hover:bg-slate-850 transition-all text-left group shadow-sm flex flex-col justify-between min-h-[110px]"
            >
              <div className="w-10 h-10 rounded-2xl bg-blue-600/20 text-blue-400 flex items-center justify-center group-hover:scale-105 transition-transform">
                <QrCode className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-white group-hover:text-blue-400 transition-colors">
                  {t.scanQr}
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Any UPI QR Code
                </div>
              </div>
            </button>

            {/* 2. To Mobile / Contact */}
            <button
              onClick={() => requestOpenSendMoney('mobile')}
              className="p-4 rounded-3xl bg-slate-900 border border-slate-800 hover:border-blue-500/50 hover:bg-slate-850 transition-all text-left group shadow-sm flex flex-col justify-between min-h-[110px]"
            >
              <div className="w-10 h-10 rounded-2xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center group-hover:scale-105 transition-transform">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-white group-hover:text-indigo-400 transition-colors">
                  {t.payContacts}
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Phone / UPI ID
                </div>
              </div>
            </button>

            {/* 3. To Bank Account / IFSC */}
            <button
              onClick={() => requestOpenSendMoney('bank')}
              className="p-4 rounded-3xl bg-slate-900 border border-slate-800 hover:border-blue-500/50 hover:bg-slate-850 transition-all text-left group shadow-sm flex flex-col justify-between min-h-[110px]"
            >
              <div className="w-10 h-10 rounded-2xl bg-sky-600/20 text-sky-400 flex items-center justify-center group-hover:scale-105 transition-transform">
                <Building className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-white group-hover:text-sky-400 transition-colors">
                  {t.payBank}
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Account & IFSC
                </div>
              </div>
            </button>

            {/* 4. Aadhaar ATM (AePS) Highlight Card */}
            <button
              onClick={() => requestOpenAePS()}
              className="p-4 rounded-3xl bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-900 border border-amber-500/40 hover:border-amber-400 transition-all text-left group shadow-sm flex flex-col justify-between min-h-[110px]"
            >
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Fingerprint className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-full">
                  AePS
                </span>
              </div>
              <div>
                <div className="text-xs font-bold text-white group-hover:text-amber-300 transition-colors">
                  {t.aepsAtm}
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Cash & Balance
                </div>
              </div>
            </button>
          </div>
        </div>

        {/* Section 3: Bharat BillPay & Recharges Grid */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-3 px-1">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <span>{t.rechargeAndBills}</span>
              <span className="text-[10px] font-semibold text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded-full border border-sky-500/20">
                BBPS Certified
              </span>
            </h2>
            <button
              onClick={() => setIsPassbookOpen(true)}
              className="text-xs text-blue-400 hover:text-blue-300 font-semibold"
            >
              {language === 'hi' ? 'बिल इतिहास देखें' : 'Bill History'} →
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-2.5">
            {/* Mobile Recharge */}
            <button
              onClick={() => setIsRechargeOpen(true)}
              className="p-3 rounded-2xl bg-slate-900 border border-slate-800 hover:border-blue-500/60 hover:bg-slate-850 transition-all flex flex-col items-center text-center gap-2 group"
            >
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Smartphone className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-white">{t.mobileRecharge}</span>
              <span className="text-[10px] text-emerald-400 font-bold">Up to 5%</span>
            </button>

            {/* Electricity */}
            <button
              onClick={() => setBillCategory('electricity')}
              className="p-3 rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-500/60 hover:bg-slate-850 transition-all flex flex-col items-center text-center gap-2 group"
            >
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Zap className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-white">{t.electricity}</span>
              <span className="text-[10px] text-emerald-400 font-bold">5% Cashback</span>
            </button>

            {/* FASTag */}
            <button
              onClick={() => setBillCategory('fastag')}
              className="p-3 rounded-2xl bg-slate-900 border border-slate-800 hover:border-indigo-500/60 hover:bg-slate-850 transition-all flex flex-col items-center text-center gap-2 group"
            >
              <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Car className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-white">{t.fastag}</span>
              <span className="text-[10px] text-emerald-400 font-bold">3.5% Back</span>
            </button>

            {/* DTH */}
            <button
              onClick={() => setBillCategory('dth')}
              className="p-3 rounded-2xl bg-slate-900 border border-slate-800 hover:border-pink-500/60 hover:bg-slate-850 transition-all flex flex-col items-center text-center gap-2 group"
            >
              <div className="w-10 h-10 rounded-xl bg-pink-500/20 text-pink-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Tv className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-white">{t.dth}</span>
              <span className="text-[10px] text-emerald-400 font-bold">4% Cashback</span>
            </button>

            {/* LPG Cylinder */}
            <button
              onClick={() => setBillCategory('cylinder')}
              className="p-3 rounded-2xl bg-slate-900 border border-slate-800 hover:border-orange-500/60 hover:bg-slate-850 transition-all flex flex-col items-center text-center gap-2 group"
            >
              <div className="w-10 h-10 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Flame className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-white">{t.cylinder}</span>
              <span className="text-[10px] text-emerald-400 font-bold">₹50 Back</span>
            </button>

            {/* Water */}
            <button
              onClick={() => setBillCategory('water')}
              className="p-3 rounded-2xl bg-slate-900 border border-slate-800 hover:border-cyan-500/60 hover:bg-slate-850 transition-all flex flex-col items-center text-center gap-2 group"
            >
              <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Droplet className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-white">{t.water}</span>
              <span className="text-[10px] text-emerald-400 font-bold">3% Back</span>
            </button>

            {/* Broadband */}
            <button
              onClick={() => setBillCategory('broadband')}
              className="p-3 rounded-2xl bg-slate-900 border border-slate-800 hover:border-purple-500/60 hover:bg-slate-850 transition-all flex flex-col items-center text-center gap-2 group"
            >
              <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Wifi className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-white">{t.broadband}</span>
              <span className="text-[10px] text-emerald-400 font-bold">4% Back</span>
            </button>

            {/* Credit Card */}
            <button
              onClick={() => setBillCategory('credit_card')}
              className="p-3 rounded-2xl bg-slate-900 border border-slate-800 hover:border-emerald-500/60 hover:bg-slate-850 transition-all flex flex-col items-center text-center gap-2 group"
            >
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <CreditCard className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-white">{t.creditCard}</span>
              <span className="text-[10px] text-emerald-400 font-bold">2.5% Back</span>
            </button>
          </div>
        </div>

        {/* Section 4: Scratch Cards & Rewards Showcase */}
        <div className="mb-8 p-5 rounded-3xl bg-slate-900 border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Gift className="w-5 h-5 text-amber-400" />
              <h2 className="text-sm font-bold text-white">
                {language === 'hi' ? 'आपके स्क्रैच कार्ड एवं रिवॉर्ड्स' : 'Your Scratch Cards & Rewards'}
              </h2>
            </div>
            <button
              onClick={() => setIsCashbackHubOpen(true)}
              className="text-xs font-semibold text-amber-400 hover:underline"
            >
              {language === 'hi' ? 'सभी देखें' : 'View Hub'} →
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Scratch Card 1 */}
            <div
              onClick={() => setActiveScratchTxn(transactions[0])}
              className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-amber-600/20 border border-amber-500/30 cursor-pointer hover:border-amber-400 transition-all flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/30 flex items-center justify-center text-amber-300">
                  <Gift className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white">
                    {language === 'hi' ? 'लकी स्क्रैच कार्ड' : 'Lucky Scratch Card'}
                  </div>
                  <div className="text-[11px] text-amber-300">
                    {language === 'hi' ? 'टैप करके स्क्रैच करें' : 'Tap to reveal cashback'}
                  </div>
                </div>
              </div>
              <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
            </div>

            {/* Refer & Earn Card */}
            <div
              onClick={() => setIsReferEarnOpen(true)}
              className="p-4 rounded-2xl bg-gradient-to-br from-amber-500/15 via-orange-500/15 to-slate-950 border border-amber-500/40 cursor-pointer hover:border-amber-400 transition-all flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/30 flex items-center justify-center text-amber-400 group-hover:scale-105 transition-transform">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <span>{language === 'hi' ? 'रेफर एवं कमाएं' : 'Refer & Earn'}</span>
                    <span className="text-[10px] font-bold text-amber-300 bg-amber-500/20 px-1.5 py-0.5 rounded-full">
                      ₹150
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-300">
                    {language === 'hi' ? 'प्रति मित्र ₹150 पाएं' : 'Get ₹150 per friend'}
                  </div>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-amber-400 group-hover:translate-x-1 transition-transform" />
            </div>

            {/* Benefit 2: Daily Streak */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-white">
                  {language === 'hi' ? 'दैनिक भुगतान स्ट्रीक' : 'Daily Payment Streak'}
                </div>
                <div className="text-[11px] text-slate-400">
                  {language === 'hi' ? '7 दिन लगातार · +5% वीआईपी' : '7 Days active · +5% VIP Tier'}
                </div>
              </div>
              <span className="text-xs font-bold text-emerald-400 font-mono">7/7 Days</span>
            </div>

            {/* Benefit 3: Soundbox auto voice */}
            <div
              onClick={() => setIsSoundboxOpen(true)}
              className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-blue-500/40 cursor-pointer transition-all flex items-center justify-between"
            >
              <div className="flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-blue-400" />
                <div>
                  <div className="text-xs font-bold text-white">Smart Soundbox</div>
                  <div className="text-[11px] text-slate-400">
                    {soundboxConfig.enabled ? 'Audio Alert Active' : 'Soundbox Off'}
                  </div>
                </div>
              </div>
              <span className="text-[10px] text-blue-400 font-semibold underline">Settings</span>
            </div>
          </div>
        </div>

        {/* Section 5: Recent Transactions with Instant Receipt Download */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-3 px-1">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-300">
              {t.recentTransactions}
            </h2>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsDownloadCenterOpen(true)}
                className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1 bg-emerald-500/10 hover:bg-emerald-500/20 px-2.5 py-1 rounded-xl border border-emerald-500/30 transition-all shadow-sm"
              >
                <Download className="w-3.5 h-3.5 text-emerald-400" />
                <span>{language === 'hi' ? 'डाउनलोड केंद्र' : 'Download Center'}</span>
              </button>
              <button
                onClick={() => setIsPassbookOpen(true)}
                className="text-xs text-blue-400 hover:text-blue-300 font-semibold flex items-center gap-1"
              >
                <span>{t.viewAll}</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="divide-y divide-slate-800/80 rounded-3xl bg-slate-900 border border-slate-800 overflow-hidden shadow-lg">
            {transactions.slice(0, 5).map((txn) => (
              <div
                key={txn.id}
                onClick={() => setActiveReceiptTxn(txn)}
                className="p-4 hover:bg-slate-850/70 transition-colors cursor-pointer flex items-center justify-between gap-3 group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-center shrink-0 group-hover:border-slate-700">
                    {txn.type === 'recharge' ? (
                      <Smartphone className="w-5 h-5 text-blue-400" />
                    ) : txn.type === 'bill_pay' ? (
                      <Zap className="w-5 h-5 text-amber-400" />
                    ) : txn.type.startsWith('aeps') ? (
                      <Fingerprint className="w-5 h-5 text-orange-400" />
                    ) : (
                      <ArrowLeftRight className="w-5 h-5 text-emerald-400" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-white truncate group-hover:text-blue-400 transition-colors">
                      {txn.title}
                    </div>
                    <div className="text-[11px] text-slate-400 truncate">
                      {txn.recipientName}
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono">
                      {txn.timestamp} · {txn.utrNumber}
                    </div>
                  </div>
                </div>

                <div className="text-right shrink-0 flex flex-col items-end">
                  <div className="text-sm font-mono font-bold text-white">
                    {formatINR(txn.amount)}
                  </div>
                  <div className="text-[11px] font-bold text-emerald-400 flex items-center justify-end gap-1 mt-0.5">
                    <Sparkles className="w-3 h-3" />
                    +{formatINR(txn.cashbackAmount)}
                  </div>

                  {/* 1-Click Instant Download Button */}
                  <div className="flex items-center gap-2 mt-1.5">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        downloadReceiptAsImage(txn);
                      }}
                      className="py-1 px-2.5 rounded-lg bg-blue-600/20 hover:bg-blue-600/40 text-blue-300 hover:text-white border border-blue-500/30 text-[10px] font-bold flex items-center gap-1 transition-all active:scale-95"
                      title="1-Click Download Receipt (PNG)"
                    >
                      <Download className="w-3 h-3 text-blue-400" />
                      <span>{language === 'hi' ? 'रसीद डाउनलोड' : 'Download Slip'}</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer info & Trust badge */}
        <footer className="text-center py-6 border-t border-slate-900 text-xs text-slate-500 space-y-2">
          <div className="flex items-center justify-center gap-4 flex-wrap">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> NPCI Unified Payments Interface
            </span>
            <span>·</span>
            <span>Bharat BillPay (BBPS)</span>
            <span>·</span>
            <span>Aadhaar AePS (UIDAI RD Service)</span>
          </div>
          <p>© 2026 PayBharat Technologies India Ltd · All rights reserved.</p>
        </footer>
      </main>

      {/* MODALS */}

      {/* 0. Security Verification PIN Overlay */}
      <SecurityPinModal
        isOpen={pendingSecureAction !== null}
        onClose={() => setPendingSecureAction(null)}
        onSuccess={handleSecuritySuccess}
        targetModuleName={pendingSecureAction?.label || 'Secure Service'}
        language={language}
      />

      {/* 1. Scan Any QR */}
      <ScanQRModal
        isOpen={isScanOpen}
        onClose={() => setIsScanOpen(false)}
        language={language}
        user={user}
        onSuccessPayment={handlePaymentSuccess}
      />

      {/* 2. Send Money / Check Balance */}
      <SendMoneyModal
        isOpen={sendMoneyMode !== null}
        onClose={() => setSendMoneyMode(null)}
        language={language}
        user={user}
        banks={banks}
        initialMode={sendMoneyMode || 'mobile'}
        onSuccessPayment={handlePaymentSuccess}
      />

      {/* 3. Aadhaar ATM (AePS) */}
      <AadhaarAePSModal
        isOpen={isAePSOpen}
        onClose={() => setIsAePSOpen(false)}
        language={language}
        onSuccessTransaction={handlePaymentSuccess}
      />

      {/* 4. Mobile Recharge */}
      <RechargeModal
        isOpen={isRechargeOpen}
        onClose={() => setIsRechargeOpen(false)}
        language={language}
        onSuccessPayment={handlePaymentSuccess}
      />

      {/* 5. Bharat BillPay */}
      <BillPayModal
        isOpen={billCategory !== null}
        onClose={() => setBillCategory(null)}
        language={language}
        initialCategory={billCategory || 'electricity'}
        onSuccessPayment={handlePaymentSuccess}
      />

      {/* 6. Smart Soundbox Settings */}
      <SoundboxModal
        isOpen={isSoundboxOpen}
        onClose={() => setIsSoundboxOpen(false)}
        config={soundboxConfig}
        onChangeConfig={setSoundboxConfig}
        currentLang={language}
      />

      {/* 7. Passbook Drawer */}
      <PassbookDrawer
        isOpen={isPassbookOpen}
        onClose={() => setIsPassbookOpen(false)}
        language={language}
        transactions={transactions}
        user={user}
        onSelectTxn={(txn) => {
          setIsPassbookOpen(false);
          setActiveReceiptTxn(txn);
        }}
        onOpenDownloadApp={() => {
          setIsPassbookOpen(false);
          setIsDownloadAppOpen(true);
        }}
      />

      {/* 8. Cashback Rewards Hub */}
      <CashbackRewardsHub
        isOpen={isCashbackHubOpen}
        onClose={() => setIsCashbackHubOpen(false)}
        language={language}
        user={user}
        primaryBank={banks[0]}
        onTransferCashback={handleTransferCashback}
      />

      {/* 8.5 Dedicated Download Center Modal */}
      <DownloadCenterModal
        isOpen={isDownloadCenterOpen}
        onClose={() => setIsDownloadCenterOpen(false)}
        language={language}
        transactions={transactions}
        user={user}
      />

      {/* 8.8 Dedicated Download App Modal */}
      <DownloadAppModal
        isOpen={isDownloadAppOpen}
        onClose={() => setIsDownloadAppOpen(false)}
        language={language}
      />

      {/* 8.9 Refer & Earn Modal */}
      <ReferEarnModal
        isOpen={isReferEarnOpen}
        onClose={() => setIsReferEarnOpen(false)}
        language={language}
        user={user}
        onRewardClaimed={handleReferralRewardClaimed}
      />

      {/* 9. Payment Receipt Modal (with PNG Image download & PDF print) */}
      <ReceiptModal
        txn={activeReceiptTxn}
        isOpen={activeReceiptTxn !== null}
        onClose={() => setActiveReceiptTxn(null)}
        language={language}
        onOpenScratchCard={(txn) => setActiveScratchTxn(txn)}
      />

      {/* 10. Interactive Scratch Card Modal */}
      <ScratchCardModal
        txn={activeScratchTxn}
        isOpen={activeScratchTxn !== null}
        onClose={() => setActiveScratchTxn(null)}
        language={language}
      />

      {/* 11. Add Money Modal */}
      {isAddMoneyOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white shadow-2xl">
            <h3 className="text-base font-bold text-white mb-1">
              {language === 'hi' ? 'वॉलेट में पैसे जोड़ें' : 'Add Money to Wallet'}
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Get an instant 2% bonus cashback credited to your wallet balance!
            </p>

            <div className="relative mb-3">
              <span className="absolute left-3.5 top-2.5 font-bold font-mono text-slate-400">₹</span>
              <input
                type="number"
                value={addAmount || ''}
                onChange={(e) => setAddAmount(Number(e.target.value))}
                min={100}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-4 py-2.5 text-base font-mono font-bold text-white focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="flex gap-2 mb-4">
              {[500, 1000, 2000, 5000].map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => setAddAmount(amt)}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${
                    addAmount === amt
                      ? 'border-blue-500 bg-blue-500/20 text-blue-300'
                      : 'border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  ₹{amt}
                </button>
              ))}
            </div>

            <div className="p-3 bg-emerald-950/40 rounded-xl border border-emerald-500/30 text-xs text-emerald-300 flex items-center justify-between mb-4">
              <span>Instant 2% Top-up Bonus:</span>
              <span className="font-mono font-bold">+{formatINR(addAmount * 0.02)}</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setIsAddMoneyOpen(false)}
                className="py-2.5 rounded-xl bg-slate-800 text-slate-300 font-semibold text-xs hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmAddMoney}
                className="py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md"
              >
                Add {formatINR(addAmount)}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
