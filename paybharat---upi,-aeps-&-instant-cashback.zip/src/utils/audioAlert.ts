/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Web Audio API chime generator + Web Speech API voice alert
export function playPaymentChime() {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();

    // Two-tone pleasant payment success chord (E5 -> B5 -> E6)
    const notes = [659.25, 987.77, 1318.51];
    notes.forEach((freq, index) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime + index * 0.08);

      gain.gain.setValueAtTime(0, ctx.currentTime + index * 0.08);
      gain.gain.linearRampToValueAtTime(0.2, ctx.currentTime + index * 0.08 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + index * 0.08 + 0.4);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime + index * 0.08);
      osc.stop(ctx.currentTime + index * 0.08 + 0.45);
    });
  } catch (err) {
    console.warn('AudioContext not available:', err);
  }
}

export function speakSoundboxAlert(amount: number, language: 'hi' | 'en' = 'hi', cashbackAmount?: number) {
  // First play the iconic soundbox chime
  playPaymentChime();

  if (!('speechSynthesis' in window)) return;

  setTimeout(() => {
    try {
      window.speechSynthesis.cancel(); // Stop any pending speech

      const text =
        language === 'hi'
          ? `पेभारत पर ${Math.round(amount)} रुपये प्राप्त हुए! ${
              cashbackAmount ? `और ${cashbackAmount.toFixed(1)} रुपये तुरंत कैशबैक मिला!` : ''
            }`
          : `Rupees ${Math.round(amount)} received on PayBharat! ${
              cashbackAmount ? `With ${cashbackAmount.toFixed(1)} rupees instant cashback credited!` : ''
            }`;

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      utterance.pitch = 1.05;
      utterance.lang = language === 'hi' ? 'hi-IN' : 'en-IN';

      // Pick an Indian English or Hindi voice if available
      const voices = window.speechSynthesis.getVoices();
      const matchedVoice = voices.find((v) =>
        language === 'hi' ? v.lang.includes('hi') : v.lang.includes('IN') || v.name.includes('India')
      );
      if (matchedVoice) {
        utterance.voice = matchedVoice;
      }

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('Speech synthesis error:', e);
    }
  }, 450);
}
