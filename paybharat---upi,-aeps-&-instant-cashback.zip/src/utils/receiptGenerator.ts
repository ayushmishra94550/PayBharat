/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Transaction } from '../types';

export function formatINR(val: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
    minimumFractionDigits: val % 1 === 0 ? 0 : 2,
  }).format(val);
}

/**
 * Generates an authentic, crisp graphic receipt as a downloadable PNG image
 */
export function downloadReceiptAsImage(txn: Transaction) {
  const canvas = document.createElement('canvas');
  const width = 640;
  const height = 860;
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  // Background gradient / Card canvas
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);

  // Top header bar (Navy / BharatPay theme)
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(0, 0, width, 140);

  // App Logo & Header text
  ctx.fillStyle = '#38bdf8';
  ctx.font = 'bold 28px sans-serif';
  ctx.fillText('⚡ PayBharat', 40, 56);

  ctx.fillStyle = '#94a3b8';
  ctx.font = '13px sans-serif';
  ctx.fillText('NPCI / UPI Verified Payment Receipt', 40, 84);

  // Cashback badge in top right
  ctx.fillStyle = '#10b981';
  ctx.beginPath();
  ctx.roundRect(width - 240, 42, 200, 36, 18);
  ctx.fill();

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 13px sans-serif';
  ctx.fillText(`★ ${(txn.cashbackRate * 100).toFixed(1)}% Cashback Earned`, width - 225, 65);

  // Success Checkmark Circle
  ctx.fillStyle = '#ecfdf5';
  ctx.beginPath();
  ctx.arc(width / 2, 195, 36, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#10b981';
  ctx.beginPath();
  ctx.arc(width / 2, 195, 30, 0, Math.PI * 2);
  ctx.fill();

  // Draw Check symbol
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 4;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(width / 2 - 12, 195);
  ctx.lineTo(width / 2 - 3, 204);
  ctx.lineTo(width / 2 + 14, 187);
  ctx.stroke();

  // Status text
  ctx.fillStyle = '#065f46';
  ctx.font = 'bold 18px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('Payment Successful', width / 2, 252);

  // Large Amount
  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 42px monospace';
  ctx.fillText(formatINR(txn.amount), width / 2, 305);

  // Cashback callout card
  ctx.fillStyle = '#f0fdf4';
  ctx.strokeStyle = '#bbf7d0';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.roundRect(40, 335, width - 80, 54, 12);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = '#15803d';
  ctx.font = 'bold 15px sans-serif';
  ctx.fillText(`🎉 Instant Cashback Credited: +${formatINR(txn.cashbackAmount)}`, width / 2, 368);

  // Hairline divider
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(40, 420);
  ctx.lineTo(width - 40, 420);
  ctx.stroke();

  // Details Table
  ctx.textAlign = 'left';
  const leftX = 45;
  const rightX = width - 45;
  let currentY = 460;

  const row = (label: string, value: string, isMono = false) => {
    ctx.fillStyle = '#64748b';
    ctx.font = '14px sans-serif';
    ctx.fillText(label, leftX, currentY);

    ctx.fillStyle = '#0f172a';
    ctx.font = isMono ? 'bold 13px monospace' : '600 14px sans-serif';
    const valWidth = ctx.measureText(value).width;
    ctx.fillText(value, rightX - valWidth, currentY);

    currentY += 40;
  };

  row('Transaction ID', txn.id, true);
  row('Paid To / Service', txn.recipientName.slice(0, 28));
  row('Category', txn.category);
  row('Payment Mode', txn.paymentMethod);
  row('Bank Ref / UTR', txn.utrNumber, true);
  row('Date & Time', txn.timestamp);
  row('Status', 'SUCCESS (NPCI Settled)');

  // Footer bar with safety seal
  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(0, height - 90, width, 90);

  ctx.fillStyle = '#94a3b8';
  ctx.font = '12px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('100% Secured by NPCI UPI Guidelines & 256-bit Encryption', width / 2, height - 52);
  ctx.fillText('PayBharat Technologies India Ltd · 24x7 Customer Support: 1800-889-PAY', width / 2, height - 32);

  // Trigger download
  const imageUri = canvas.toDataURL('image/png');
  const downloadLink = document.createElement('a');
  downloadLink.download = `PayBharat_Receipt_${txn.id}.png`;
  downloadLink.href = imageUri;
  downloadLink.click();
}

/**
 * Downloads a CSV statement of transactions
 */
export function downloadStatementAsCSV(transactions: Transaction[]) {
  const headers = [
    'Transaction ID',
    'Date & Time',
    'Title',
    'Category',
    'Recipient / Service',
    'Amount (INR)',
    'Cashback %',
    'Cashback Earned (INR)',
    'Payment Mode',
    'UTR Reference',
    'Status',
  ];

  const rows = transactions.map((t) => [
    t.id,
    `"${t.timestamp}"`,
    `"${t.title.replace(/"/g, '""')}"`,
    `"${t.category}"`,
    `"${t.recipientName.replace(/"/g, '""')}"`,
    t.amount.toFixed(2),
    `${(t.cashbackRate * 100).toFixed(1)}%`,
    t.cashbackAmount.toFixed(2),
    `"${t.paymentMethod}"`,
    t.utrNumber,
    t.status,
  ]);

  const csvContent =
    'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', `PayBharat_Statement_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
