/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Language = 'hi' | 'en';

export type TransactionType =
  | 'send_money'
  | 'receive_money'
  | 'recharge'
  | 'bill_pay'
  | 'aeps_withdrawal'
  | 'aeps_aadhaar_pay'
  | 'cashback_credit';

export type TransactionStatus = 'SUCCESS' | 'PENDING' | 'FAILED';

export interface Transaction {
  id: string;
  type: TransactionType;
  title: string;
  recipientName: string;
  recipientInfo: string; // UPI ID, Phone, or Account/Bank
  amount: number;
  cashbackRate: number; // e.g. 0.035 for 3.5%
  cashbackAmount: number; // e.g. 17.50
  status: TransactionStatus;
  timestamp: string; // ISO or readable
  utrNumber: string;
  paymentMethod: string;
  category: string;
  notes?: string;
  scratched?: boolean;
}

export type AePSService = 'withdrawal' | 'balance' | 'mini_statement' | 'aadhaar_pay';

export interface AePSTransactionResult {
  rrn: string;
  aadhaarLast4: string;
  bankName: string;
  service: AePSService;
  amount: number;
  cashbackAmount: number;
  balanceAfter?: number;
  status: 'SUCCESS' | 'FAILED';
  timestamp: string;
  authMessage: string;
}

export interface BankAccount {
  id: string;
  bankName: string;
  accountNumberMasked: string;
  ifsc: string;
  isPrimary: boolean;
  balance: number;
  logoColor: string;
}

export interface UserProfile {
  name: string;
  phone: string;
  upiId: string;
  aadhaarNumberMasked: string;
  walletBalance: number;
  cashbackBalance: number;
  totalCashbackLifetime: number;
  kycStatus: 'VERIFIED' | 'PENDING';
  tier: 'Silver (2%)' | 'Gold (3.5%)' | 'Platinum VIP (5%)';
}

export interface RechargePlan {
  id: string;
  operator: 'Jio' | 'Airtel' | 'Vi' | 'BSNL';
  price: number;
  validity: string;
  data: string;
  calls: string;
  benefits: string;
  cashbackPercent: number;
  isPopular?: boolean;
  category: 'Unlimited' | 'Daily Data' | 'Long Term' | 'Data Booster' | 'Entertainment OTT';
}

export interface BillBiller {
  id: string;
  name: string;
  category: BillCategory;
  state?: string;
  identifierLabel: string; // e.g., 'Consumer Number', 'Vehicle Number', 'Subscriber ID'
  identifierPlaceholder: string;
  sampleAmount: number;
}

export type BillCategory =
  | 'electricity'
  | 'fastag'
  | 'dth'
  | 'cylinder'
  | 'water'
  | 'broadband'
  | 'credit_card';

export interface SoundboxConfig {
  enabled: boolean;
  volume: number; // 0 to 1
  language: 'hi' | 'en';
}
